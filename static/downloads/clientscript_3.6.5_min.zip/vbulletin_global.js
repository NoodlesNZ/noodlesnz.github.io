
if(typeof(SESSIONURL)=="undefined")
{var SESSIONURL="";}
if(typeof(vbphrase)=="undefined")
{var vbphrase=new Array();}
var vB_Editor=new Array();var ignorequotechars=false;var pagenavcounter=0;var userAgent=navigator.userAgent.toLowerCase();var is_opera=((userAgent.indexOf('opera')!=-1)||(typeof(window.opera)!='undefined'));var is_saf=((userAgent.indexOf('applewebkit')!=-1)||(navigator.vendor=='Apple Computer, Inc.'));var is_webtv=(userAgent.indexOf('webtv')!=-1);var is_ie=((userAgent.indexOf('msie')!=-1)&&(!is_opera)&&(!is_saf)&&(!is_webtv));var is_ie4=((is_ie)&&(userAgent.indexOf('msie 4.')!=-1));var is_ie7=((is_ie)&&(userAgent.indexOf('msie 7.')!=-1));var is_moz=((navigator.product=='Gecko')&&(!is_saf));var is_kon=(userAgent.indexOf('konqueror')!=-1);var is_ns=((userAgent.indexOf('compatible')==-1)&&(userAgent.indexOf('mozilla')!=-1)&&(!is_opera)&&(!is_webtv)&&(!is_saf));var is_ns4=((is_ns)&&(parseInt(navigator.appVersion)==4));var is_mac=(userAgent.indexOf('mac')!=-1);var is_regexp=(window.RegExp)?true:false;var AJAX_Compatible=false;var pointer_cursor=(is_ie?'hand':'pointer');String.prototype.vBlength=function()
{return(is_ie&&this.indexOf('\n')!=-1)?this.replace(/\r?\n/g,'_').length:this.length;}
if('1234'.substr(-2,2)=='12')
{String.prototype.substr_orig=String.prototype.substr;String.prototype.substr=function(start,length)
{return this.substr_orig((start<0?this.length+start:start),length);};}
function array_pop(a)
{if(typeof a!='object'||!a.length)
{return null;}
else
{var response=a[a.length-1];a.length--;return response;}}
if(typeof Array.prototype.shift==='undefined')
{Array.prototype.shift=function()
{for(var i=0,b=this[0],l=this.length-1;i<l;i++)
{this[i]=this[i+1];}
this.length--;return b;};}
function array_push(a,values)
{for(var i=1;i<arguments.length;i++)
{a[a.length]=arguments[i];}
return a.length;}
function fetch_object(idname)
{if(document.getElementById)
{return document.getElementById(idname);}
else if(document.all)
{return document.all[idname];}
else if(document.layers)
{return document.layers[idname];}
else
{return null;}}
function fetch_tags(parentobj,tag)
{if(parentobj==null)
{return new Array();}
else if(typeof parentobj.getElementsByTagName!='undefined')
{return parentobj.getElementsByTagName(tag);}
else if(parentobj.all&&parentobj.all.tags)
{return parentobj.all.tags(tag);}
else
{return new Array();}}
function fetch_tag_count(parentobj,tag)
{return fetch_tags(parentobj,tag).length;}
function do_an_e(eventobj)
{if(!eventobj||is_ie)
{window.event.returnValue=false;window.event.cancelBubble=true;return window.event;}
else
{eventobj.stopPropagation();eventobj.preventDefault();return eventobj;}}
function e_by_gum(eventobj)
{if(!eventobj||is_ie)
{window.event.cancelBubble=true;return window.event;}
else
{if(eventobj.target.type=='submit')
{eventobj.target.form.submit();}
eventobj.stopPropagation();return eventobj;}}
function validatemessage(messagetext,subjecttext,minchars)
{if(is_kon||is_saf||is_webtv)
{return true;}
else if(subjecttext.length<1)
{alert(vbphrase['must_enter_subject']);return false;}
else
{var stripped=PHP.trim(stripcode(messagetext,false,ignorequotechars));if(stripped.length<minchars)
{alert(construct_phrase(vbphrase['message_too_short'],minchars));return false;}
else if(typeof(document.forms.vbform)!='undefined'&&typeof(document.forms.vbform.imagestamp)!='undefined')
{if(document.forms.vbform.imagestamp.value.length!=6)
{alert(vbphrase['complete_image_verification']);document.forms.vbform.imagestamp.focus();return false;}
else
{return true;}}
else
{return true;}}}
function stripcode(str,ishtml,stripquotes)
{if(!is_regexp)
{return str;}
if(stripquotes)
{var start_time=new Date().getTime();while((startindex=PHP.stripos(str,'[quote'))!==false)
{if(new Date().getTime()-start_time>2000)
{break;}
if((stopindex=PHP.stripos(str,'[/quote]'))!==false)
{fragment=str.substr(startindex,stopindex-startindex+8);str=str.replace(fragment,'');}
else
{break;}
str=PHP.trim(str);}}
if(ishtml)
{str=str.replace(/<img[^>]+src="([^"]+)"[^>]*>/gi,'$1');var html1=new RegExp("<(\\w+)[^>]*>",'gi');var html2=new RegExp("<\\/\\w+>",'gi');str=str.replace(html1,'');str=str.replace(html2,'');var html3=new RegExp('(&nbsp;)','gi');str=str.replace(html3,' ');}
else
{var bbcode1=new RegExp("\\[(\\w+)[^\\]]*\\]",'gi');var bbcode2=new RegExp("\\[\\/(\\w+)\\]",'gi');str=str.replace(bbcode1,'');str=str.replace(bbcode2,'');}
return str;}
function vB_PHP_Emulator()
{}
vB_PHP_Emulator.prototype.stripos=function(haystack,needle,offset)
{if(typeof offset=='undefined')
{offset=0;}
index=haystack.toLowerCase().indexOf(needle.toLowerCase(),offset);return(index==-1?false:index);}
vB_PHP_Emulator.prototype.ltrim=function(str)
{return str.replace(/^\s+/g,'');}
vB_PHP_Emulator.prototype.rtrim=function(str)
{return str.replace(/(\s+)$/g,'');}
vB_PHP_Emulator.prototype.trim=function(str)
{return this.ltrim(this.rtrim(str));}
vB_PHP_Emulator.prototype.preg_quote=function(str)
{return str.replace(/(\+|\{|\}|\(|\)|\[|\]|\||\/|\?|\^|\$|\\|\.|\=|\!|\<|\>|\:|\*)/g,"\\$1");}
vB_PHP_Emulator.prototype.unhtmlspecialchars=function(str)
{f=new Array(/&lt;/g,/&gt;/g,/&quot;/g,/&amp;/g);r=new Array('<','>','"','&');for(var i in f)
{str=str.replace(f[i],r[i]);}
return str;}
vB_PHP_Emulator.prototype.unescape_cdata=function(str)
{var r1=/<\=\!\=\[\=C\=D\=A\=T\=A\=\[/g;var r2=/\]\=\]\=>/g;return str.replace(r1,'<![CDATA[').replace(r2,']]>');}
vB_PHP_Emulator.prototype.htmlspecialchars=function(str)
{var f=new Array((is_mac&&is_ie?new RegExp('&','g'):new RegExp('&(?!#[0-9]+;)','g')),new RegExp('<','g'),new RegExp('>','g'),new RegExp('"','g'));var r=new Array('&amp;','&lt;','&gt;','&quot;');for(var i=0;i<f.length;i++)
{str=str.replace(f[i],r[i]);}
return str;}
vB_PHP_Emulator.prototype.in_array=function(ineedle,haystack,caseinsensitive)
{var needle=new String(ineedle);if(caseinsensitive)
{needle=needle.toLowerCase();for(var i in haystack)
{if(haystack[i].toLowerCase()==needle)
{return i;}}}
else
{for(var i in haystack)
{if(haystack[i]==needle)
{return i;}}}
return-1;}
vB_PHP_Emulator.prototype.str_pad=function(text,length,padstring)
{text=new String(text);padstring=new String(padstring);if(text.length<length)
{padtext=new String(padstring);while(padtext.length<(length-text.length))
{padtext+=padstring;}
text=padtext.substr(0,(length-text.length))+text;}
return text;}
vB_PHP_Emulator.prototype.urlencode=function(text)
{text=escape(text.toString()).replace(/\+/g,"%2B");var matches=text.match(/(%([0-9A-F]{2}))/gi);if(matches)
{for(var matchid=0;matchid<matches.length;matchid++)
{var code=matches[matchid].substring(1,3);if(parseInt(code,16)>=128)
{text=text.replace(matches[matchid],'%u00'+code);}}}
text=text.replace('%25','%u0025');return text;}
vB_PHP_Emulator.prototype.ucfirst=function(str,cutoff)
{if(typeof cutoff!='undefined')
{var cutpos=str.indexOf(cutoff);if(cutpos>0)
{str=str.substr(0,cutpos);}}
str=str.split(' ');for(var i=0;i<str.length;i++)
{str[i]=str[i].substr(0,1).toUpperCase()+str[i].substr(1);}
return str.join(' ');}
var PHP=new vB_PHP_Emulator();function vB_AJAX_Handler(async)
{this.async=async?true:false;}
vB_AJAX_Handler.prototype.init=function()
{if(typeof vb_disable_ajax!='undefined'&&vb_disable_ajax==2)
{return false;}
try
{this.handler=new XMLHttpRequest();return(this.handler.setRequestHeader?true:false);}
catch(e)
{try
{this.handler=eval("new A"+"ctiv"+"eX"+"Ob"+"ject('Micr"+"osoft.XM"+"LHTTP');");return true;}
catch(e)
{return false;}}}
vB_AJAX_Handler.prototype.is_compatible=function()
{if(typeof vb_disable_ajax!='undefined'&&vb_disable_ajax==2)
{return false;}
if(is_ie&&!is_ie4){return true;}
else if(typeof XMLHttpRequest!='undefined')
{try{return XMLHttpRequest.prototype.setRequestHeader?true:false;}
catch(e)
{try{var tester=new XMLHttpRequest();return tester.setRequestHeader?true:false;}
catch(e){return false;}}}
else{return false;}}
vB_AJAX_Handler.prototype.not_ready=function()
{return(this.handler.readyState&&(this.handler.readyState<4));}
vB_AJAX_Handler.prototype.onreadystatechange=function(event)
{if(!this.handler)
{if(!this.init())
{return false;}}
if(typeof event=='function')
{this.handler.onreadystatechange=event;}
else
{alert('XML Sender OnReadyState event is not a function');}
return false;}
vB_AJAX_Handler.prototype.send=function(desturl,datastream)
{if(!this.handler)
{if(!this.init())
{return false;}}
if(!this.not_ready())
{this.handler.open('POST',desturl,this.async);this.handler.setRequestHeader('Content-Type','application/x-www-form-urlencoded');this.handler.send(datastream+'&s='+fetch_sessionhash());if(!this.async&&this.handler.readyState==4&&this.handler.status==200)
{return true;}}
return false;}
vB_AJAX_Handler.prototype.fetch_data=function(xml_node)
{if(xml_node&&xml_node.firstChild&&xml_node.firstChild.nodeValue)
{return PHP.unescape_cdata(xml_node.firstChild.nodeValue);}
else
{return'';}}
var AJAX_Compatible=vB_AJAX_Handler.prototype.is_compatible();function vB_Hidden_Form(script)
{this.action=script;this.variables=new Array();}
vB_Hidden_Form.prototype.add_variable=function(name,value)
{this.variables[this.variables.length]=new Array(name,value);};vB_Hidden_Form.prototype.add_variables_from_object=function(obj)
{var inputs=fetch_tags(obj,'input');for(var i=0;i<inputs.length;i++)
{switch(inputs[i].type)
{case'checkbox':case'radio':if(inputs[i].checked)
{this.add_variable(inputs[i].name,inputs[i].value);}
break;case'text':case'hidden':case'password':this.add_variable(inputs[i].name,inputs[i].value);break;default:continue;}}
var textareas=fetch_tags(obj,'textarea');for(var i=0;i<textareas.length;i++)
{this.add_variable(textareas[i].name,textareas[i].value);}
var selects=fetch_tags(obj,'select');for(var i=0;i<selects.length;i++)
{if(selects[i].multiple)
{for(var j=0;j<selects[i].options.length;j++)
{if(selects[i].options[j].selected)
{this.add_variable(selects[i].name,selects[i].options[j].value);}}}
else
{this.add_variable(selects[i].name,selects[i].options[selects[i].selectedIndex].value);}}};vB_Hidden_Form.prototype.fetch_variable=function(varname)
{for(var i=0;i<this.variables.length;i++)
{if(this.variables[i][0]==varname)
{return this.variables[i][1];}}
return null;};vB_Hidden_Form.prototype.submit_form=function()
{this.form=document.createElement('form');this.form.method='post';this.form.action=this.action;for(var i=0;i<this.variables.length;i++)
{var inputobj=document.createElement('input');inputobj.type='hidden';inputobj.name=this.variables[i][0];inputobj.value=this.variables[i][1];this.form.appendChild(inputobj);}
document.body.appendChild(this.form).submit();};vB_Hidden_Form.prototype.build_query_string=function()
{var query_string='';for(var i=0;i<this.variables.length;i++)
{query_string+=this.variables[i][0]+'='+PHP.urlencode(this.variables[i][1])+'&';}
return query_string;}
vB_Hidden_Form.prototype.add_input=vB_Hidden_Form.prototype.add_variable;vB_Hidden_Form.prototype.add_inputs_from_object=vB_Hidden_Form.prototype.add_variables_from_object;function openWindow(url,width,height,windowid)
{return window.open(url,(typeof windowid=='undefined'?'vBPopup':windowid),'statusbar=no,menubar=no,toolbar=no,scrollbars=yes,resizable=yes'
+(typeof width!='undefined'?(',width='+width):'')+(typeof height!='undefined'?(',height='+height):''));}
function js_open_help(scriptname,actiontype,optionval)
{return openWindow('help.php?s='+SESSIONHASH+'&do=answer&page='+scriptname+'&pageaction='+actiontype+'&option='+optionval,600,450,'helpwindow');}
function attachments(threadid)
{return openWindow('misc.php?'+SESSIONURL+'do=showattachments&t='+threadid,480,300);}
function who(threadid)
{return openWindow('misc.php?'+SESSIONURL+'do=whoposted&t='+threadid,230,300);}
function imwindow(imtype,userid,width,height)
{return openWindow('sendmessage.php?'+SESSIONURL+'do=im&type='+imtype+'&u='+userid,width,height);}
function SendMSNMessage(name)
{if(!is_ie)
{alert(vbphrase['msn_functions_only_work_in_ie']);return false;}
else
{MsgrObj.InstantMessage(name);return false;}}
function AddMSNContact(name)
{if(!is_ie)
{alert(vbphrase['msn_functions_only_work_in_ie']);return false;}
else
{MsgrObj.AddContact(0,name);return false;}}
function detect_caps_lock(e)
{e=(e?e:window.event);var keycode=(e.which?e.which:(e.keyCode?e.keyCode:(e.charCode?e.charCode:0)));var shifted=(e.shiftKey||(e.modifiers&&(e.modifiers&4)));var ctrled=(e.ctrlKey||(e.modifiers&&(e.modifiers&2)));return(keycode>=65&&keycode<=90&&!shifted&&!ctrled)||(keycode>=97&&keycode<=122&&shifted);}
function set_cookie(name,value,expires)
{document.cookie=name+'='+escape(value)+'; path=/'+(typeof expires!='undefined'?'; expires='+expires.toGMTString():'');}
function delete_cookie(name)
{document.cookie=name+'='+'; expires=Thu, 01-Jan-70 00:00:01 GMT'+'; path=/';}
function fetch_cookie(name)
{cookie_name=name+'=';cookie_length=document.cookie.length;cookie_begin=0;while(cookie_begin<cookie_length)
{value_begin=cookie_begin+cookie_name.length;if(document.cookie.substring(cookie_begin,value_begin)==cookie_name)
{var value_end=document.cookie.indexOf(';',value_begin);if(value_end==-1)
{value_end=cookie_length;}
return unescape(document.cookie.substring(value_begin,value_end));}
cookie_begin=document.cookie.indexOf(' ',cookie_begin)+1;if(cookie_begin==0)
{break;}}
return null;}
function js_toggle_all(formobj,formtype,option,exclude,setto)
{for(var i=0;i<formobj.elements.length;i++)
{var elm=formobj.elements[i];if(elm.type==formtype&&PHP.in_array(elm.name,exclude,false)==-1)
{switch(formtype)
{case'radio':if(elm.value==option)
{elm.checked=setto;}
break;case'select-one':elm.selectedIndex=setto;break;default:elm.checked=setto;break;}}}}
function js_select_all(formobj)
{exclude=new Array();exclude[0]='selectall';js_toggle_all(formobj,'select-one','',exclude,formobj.selectall.selectedIndex);}
function js_check_all(formobj)
{exclude=new Array();exclude[0]='keepattachments';exclude[1]='allbox';exclude[2]='removeall';js_toggle_all(formobj,'checkbox','',exclude,formobj.allbox.checked);}
function js_check_all_option(formobj,option)
{exclude=new Array();exclude[0]='useusergroup';js_toggle_all(formobj,'radio',option,exclude,true);}
function checkall(formobj){js_check_all(formobj);}
function checkall_option(formobj,option){js_check_all_option(formobj,option);}
function resize_textarea(to,id)
{if(to<0)
{var rows=-5;var cols=-10;}
else
{var rows=5;var cols=10;}
var textarea=fetch_object(id);if(typeof textarea.orig_rows=='undefined')
{textarea.orig_rows=textarea.rows;textarea.orig_cols=textarea.cols;}
var newrows=textarea.rows+rows;var newcols=textarea.cols+cols;if(newrows>=textarea.orig_rows&&newcols>=textarea.orig_cols)
{textarea.rows=newrows;textarea.cols=newcols;}
return false;}
function toggle_collapse(objid)
{if(!is_regexp)
{return false;}
obj=fetch_object('collapseobj_'+objid);img=fetch_object('collapseimg_'+objid);cel=fetch_object('collapsecel_'+objid);if(!obj)
{if(img)
{img.style.display='none';}
return false;}
if(obj.style.display=='none')
{obj.style.display='';save_collapsed(objid,false);if(img)
{img_re=new RegExp("_collapsed\\.gif$");img.src=img.src.replace(img_re,'.gif');}
if(cel)
{cel_re=new RegExp("^(thead|tcat)(_collapsed)$");cel.className=cel.className.replace(cel_re,'$1');}}
else
{obj.style.display='none';save_collapsed(objid,true);if(img)
{img_re=new RegExp("\\.gif$");img.src=img.src.replace(img_re,'_collapsed.gif');}
if(cel)
{cel_re=new RegExp("^(thead|tcat)$");cel.className=cel.className.replace(cel_re,'$1_collapsed');}}
return false;}
function save_collapsed(objid,addcollapsed)
{var collapsed=fetch_cookie('vbulletin_collapse');var tmp=new Array();if(collapsed!=null)
{collapsed=collapsed.split('\n');for(var i in collapsed)
{if(collapsed[i]!=objid&&collapsed[i]!='')
{tmp[tmp.length]=collapsed[i];}}}
if(addcollapsed)
{tmp[tmp.length]=objid;}
expires=new Date();expires.setTime(expires.getTime()+(1000*86400*365));set_cookie('vbulletin_collapse',tmp.join('\n'),expires);}
function vBpagenav()
{}
vBpagenav.prototype.controlobj_onclick=function(e)
{this._onclick(e);var inputs=fetch_tags(this.menu.menuobj,'input');for(var i=0;i<inputs.length;i++)
{if(inputs[i].type=='text')
{inputs[i].focus();break;}}};vBpagenav.prototype.form_gotopage=function(e)
{if((pagenum=parseInt(fetch_object('pagenav_itxt').value,10))>0)
{window.location=this.addr+'&page='+pagenum;}
return false;};vBpagenav.prototype.ibtn_onclick=function(e)
{return this.form.gotopage();};vBpagenav.prototype.itxt_onkeypress=function(e)
{return((e?e:window.event).keyCode==13?this.form.gotopage():true);};function vbmenu_register(controlid,noimage,datefield)
{if(typeof(vBmenu)=="object")
{return vBmenu.register(controlid,noimage);}
else
{return false;}}
function set_unselectable(obj)
{if(!is_ie4&&typeof obj.tagName!='undefined')
{if(obj.hasChildNodes())
{for(var i=0;i<obj.childNodes.length;i++)
{set_unselectable(obj.childNodes[i]);}}
obj.unselectable='on';}}
function fetch_sessionhash()
{return(SESSIONURL==''?'':SESSIONURL.substr(2,32));}
function construct_phrase()
{if(!arguments||arguments.length<1||!is_regexp)
{return false;}
var args=arguments;var str=args[0];var re;for(var i=1;i<args.length;i++)
{re=new RegExp("%"+i+"\\$s",'gi');str=str.replace(re,args[i]);}
return str;}
function switch_id(selectobj,type)
{var id=selectobj.options[selectobj.selectedIndex].value;if(id=='')
{return;}
var url=new String(window.location);var fragment=new String('');url=url.split('#');if(url[1])
{fragment='#'+url[1];}
url=url[0];if(url.indexOf(type+'id=')!=-1&&is_regexp)
{re=new RegExp(type+"id=\\d+&?");url=url.replace(re,'');}
if(url.indexOf('?')==-1)
{url+='?';}
else
{lastchar=url.substr(url.length-1);if(lastchar!='&'&&lastchar!='?')
{url+='&';}}
window.location=url+type+'id='+id+fragment;}
function img_alt_2_title(img)
{if(!img.title&&img.alt!='')
{img.title=img.alt;}}
function PostBit_Init(obj,postid)
{if(typeof vBmenu!='undefined')
{var divs=fetch_tags(obj,'div');for(var i=0;i<divs.length;i++)
{if(divs[i].id&&divs[i].id.substr(0,9)=='postmenu_')
{vBmenu.register(divs[i].id,true);}}}
if(typeof vB_QuickEditor!='undefined')
{vB_AJAX_QuickEdit_Init(obj);}
if(typeof vB_QuickReply!='undefined')
{qr_init_buttons(obj);}
if(typeof mq_init!='undefined')
{mq_init(obj);}
if(typeof vBrep!='undefined')
{if(typeof postid!='undefined'&&typeof postid!='null')
{vbrep_register(postid);}}
if(typeof inlineMod!='undefined')
{im_init(obj);}}
function vBulletin_init()
{if(is_webtv)
{return false;}
var imgs=fetch_tags(document,'img');for(var i=0;i<imgs.length;i++)
{img_alt_2_title(imgs[i]);}
if(typeof vBmenu=='object')
{if(window.attachEvent&&!is_saf)
{document.attachEvent('onclick',vbmenu_hide);window.attachEvent('onresize',vbmenu_hide);}
else if(document.addEventListener&&!is_saf)
{document.addEventListener('click',vbmenu_hide,false);window.addEventListener('resize',vbmenu_hide,false);}
else
{window.onclick=vbmenu_hide;window.onresize=vbmenu_hide;}
var pagenavs=fetch_tags(document,'td');for(var n=0;n<pagenavs.length;n++)
{if(pagenavs[n].hasChildNodes()&&pagenavs[n].firstChild.name&&pagenavs[n].firstChild.name.indexOf('PageNav')!=-1)
{var addr=pagenavs[n].title;pagenavs[n].title='';pagenavs[n].innerHTML='';pagenavs[n].id='pagenav.'+n;var pn=vBmenu.register(pagenavs[n].id);if(is_saf)
{pn.controlobj._onclick=pn.controlobj.onclick;pn.controlobj.onclick=vBpagenav.prototype.controlobj_onclick;}}}
if(typeof addr!='undefined')
{fetch_object('pagenav_form').addr=addr;fetch_object('pagenav_form').gotopage=vBpagenav.prototype.form_gotopage;fetch_object('pagenav_ibtn').onclick=vBpagenav.prototype.ibtn_onclick;fetch_object('pagenav_itxt').onkeypress=vBpagenav.prototype.itxt_onkeypress;}
vBmenu.activate(true);}
return true;}