
function vB_AJAX_NameSuggest(varname,textobjid,menukey)
{var webkit_version=userAgent.match(/applewebkit\/([0-9]+)/);if(AJAX_Compatible&&!(is_saf&&!(webkit_version[1]>=412)))
{this.menuobj=fetch_object(menukey+'_menu');this.textobj=fetch_object(textobjid);this.textobj.onfocus=function(e){this.obj.active=true;};this.textobj.onblur=function(e){this.obj.active=false;};this.textobj.obj=this;this.varname=varname;this.menukey=menukey;this.fragment='';this.donenames='';this.selected=0;this.menuopen=false;this.timeout=null;this.names=new Array();this.xml_sender=null;this.active=false;this.allow_multiple=false;this.min_chars=3;this.get_text=function()
{if(this.allow_multiple)
{var semicolon=this.textobj.value.lastIndexOf(';');if(semicolon==-1)
{this.donenames=new String('');this.fragment=new String(this.textobj.value);}
else
{this.donenames=new String(this.textobj.value.substring(0,semicolon+1));this.fragment=new String(this.textobj.value.substring(semicolon+1));}}
else
{this.fragment=new String(this.textobj.value);}
this.fragment=PHP.trim(this.fragment);}
this.set_text=function(i)
{if(this.allow_multiple)
{this.textobj.value=PHP.ltrim(this.donenames+" "+PHP.unhtmlspecialchars(this.names[i])+" ; ");}
else
{this.textobj.value=PHP.unhtmlspecialchars(this.names[i]);}
this.textobj.focus();this.menu_hide();return false;}
this.move_row_selection=function(increment)
{var newval=parseInt(this.selected,10)+parseInt(increment,10);if(newval<0)
{newval=this.names.length-1;}
else if(newval>=this.names.length)
{newval=0;}
this.set_row_selection(newval);return false;}
this.set_row_selection=function(i)
{var tds=fetch_tags(this.menuobj,'td');tds[this.selected].className='vbmenu_option';this.selected=i;tds[this.selected].className='vbmenu_hilite';}
this.key_event_handler=function(evt)
{evt=evt?evt:window.event;if(this.menuopen)
{switch(evt.keyCode)
{case 38:{this.move_row_selection(-1);return false;}
case 40:{this.move_row_selection(1);return false;}
case 27:{this.menu_hide();return false;}
case 13:{this.set_text(this.selected);return false;}}}
this.get_text();if(this.fragment.length>=this.min_chars)
{clearTimeout(this.timeout);this.timeout=setTimeout(this.varname+'.name_search();',500);}
else
{this.menu_hide();}}
this.name_search=function()
{if(this.active)
{this.names=new Array();if(!this.xml_sender)
{this.xml_sender=new vB_AJAX_Handler(true);}
this.xml_sender.onreadystatechange(this.onreadystatechange);this.xml_sender.send('ajax.php?do=usersearch','do=usersearch&fragment='+PHP.urlencode(this.fragment));}}
var me=this;this.onreadystatechange=function()
{if(me.xml_sender.handler.readyState==4&&me.xml_sender.handler.status==200&&me.xml_sender.handler.responseXML)
{var users=fetch_tags(me.xml_sender.handler.responseXML,'user');for(i=0;i<users.length;i++)
{me.names[i]=me.xml_sender.fetch_data(users[i]);}
if(me.names.length>0)
{me.menu_build();me.menu_show();}
else
{me.menu_hide();}
me.xml_sender.handler.abort();}}
this.menu_build=function()
{this.menu_empty();var re=new RegExp('^('+PHP.preg_quote(this.fragment)+')',"i");var table=document.createElement('table');table.cellPadding=4;table.cellSpacing=1;table.border=0;for(i in this.names)
{var td=table.insertRow(-1).insertCell(-1);td.className=(i==this.selected?'vbmenu_hilite':'vbmenu_option');td.title='nohilite';td.innerHTML='<a onclick="return '+this.varname+'.set_text('+i+')">'+this.names[i].replace(re,'<strong>$1</strong>')+'</a>';}
this.menuobj.appendChild(table);if(this.vbmenu==null)
{if(typeof(vBmenu.menus[this.menukey])!='undefined')
{this.vbmenu=vBmenu.menus[this.menukey];}
else
{this.vbmenu=vBmenu.register(this.menukey,true);}}
else
{this.vbmenu.init_menu_contents();}}
this.menu_empty=function()
{this.selected=0;while(this.menuobj.firstChild)
{this.menuobj.removeChild(this.menuobj.firstChild);}}
this.menu_show=function()
{if(this.active)
{this.vbmenu.show(fetch_object(this.menukey),this.menuopen);this.menuopen=true;}}
this.menu_hide=function()
{try
{this.vbmenu.hide();}
catch(e){}
this.menuopen=false;}
this.textobj.onkeyup=function(e){return this.obj.key_event_handler(e);};this.textobj.onkeypress=function(e)
{e=e?e:window.event;if(e.keyCode==13)
{return(this.obj.menuopen?false:true);}};}}