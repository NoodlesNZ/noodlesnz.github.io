<?php
  include 'class_sitemap.php';
  
  $sitemap = new Google_Sitemap();
  $sitemap->baseurl = "http://www.noodles.net.nz";
  
  //add urls (I'm just generating junk urls to fill the sitemap)
  for($i=0;$i<=100;$i++){
    $sitemap->addItem(array("loc" => "/page$i.html"));
  }
  
  //build sitemap
  $sitemap->build();
  
  //show stats
  echo "<pre>\n";
  print_r($sitemap->getStats());
  echo "</pre>";
?>
