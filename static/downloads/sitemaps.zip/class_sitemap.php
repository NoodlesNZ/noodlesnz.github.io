<?php
/**
* Parent class for generating sitemaps
* 
* PHP version 5
*
* @author     Nick Le Mouton <noodles@planetslackers.com>
* @link       http://www.noodles.net.nz/sitemaps/
* @licence    GPL, see www.gnu.org/copyleft/gpl.html
* @version    0.2
*/

class Sitemap {
  public $baseurl = ""; //url of your site, e.g. http://www.noodles.net.nz (no trailing slash) (Required)
  public $basefilename = "sitemap_"; //changes filename of sitemaps, default is sitemap_1.xml, sitemap_index.xml, etc. (Optional)
  public $basedir = ""; //where the sitemaps are to be stored. Default is the same directory as the calling page. (Optional)
  public $sitemap_baseurl = ""; //url of your sitemaps. Default is your baseurl. Read this if you're unsure: https://www.google.com/webmasters/tools/docs/en/protocol.html#sitemapLocation (Optional)
  public $gzip = true; //use GZip to compress your sitemaps (Optional)
  
  //internal variables
  public $sitemaps = 0;
  public $items = array();
  public $stats = array();

  function __construct(){
    
  }

  /** Adds a new item to the channel contents.
   * @param sitemap item $item
   */
  function addItem($item){
    $this->items[] = $item;
  }

  function build(){
  }
  
  function writeSitemap(){
  }
  
  /**
  * Returns status of Gzip
  * @return boolean
  */
  function isGzip(){
    if($this->gzip And function_exists('gzencode')){
      return true;
    } else {
      return false;
    }
  }
  
  /**
  * Makes http query
  * @param string $url
  * @return boolean
  */
  function query_http($url){
    ini_set('default_socket_timeout', 5);
    $purl = parse_url($url);
    $connsocket = @fsockopen($purl['host'], 80, $errno, $errstr, 5);
    $start = 0;
    $timeout = 50;
    while($start < $timeout){
      $start++;
      if ($connsocket){
        $start = 100;
        $out = "GET ".$url." HTTP/1.0\n";
        $out .= "Host: ".$purl['host']."\n";
        $out .= "Referer: http://".$purl['host']."/\n";
        $out .= "Connection: Close\n\n";
        $inp = '';
        @fwrite($connsocket, $out);
        while (!feof($connsocket)) {
         $inp .= @fread($connsocket, 4096);
        }
        @fclose($connsocket);
      }
    }

    preg_match("#^(.*?)\r?\n\r?\n(.*)$#s",$inp,$hm);
    $headersstr = $hm[1] ? $hm[1] : $inp;
    $headers = split("\r?\n", $headersstr);
    list($proto, $code) = sscanf($headers[0], '%s %s');

    return $code==200;
  }
}

/**
* Class for creating Google sitemaps
*/
class Google_Sitemap extends Sitemap {
  public $maxurls = 50000; //max number of urls in a sitemap file (Optional)
  public $doPing = true; //toggles ping (Optional)
  
  //internal variables
  public $pingSuccess = false;
  
  /**
   * Generates the sitemap XML data based on object properties.
   */
  function build(){
    $count = 1;
    $content = "";
    foreach($this->items as $item){
      $item['loc'] = htmlentities($item['loc'], ENT_QUOTES);
      $content .= "\t\t<url>\n\t\t\t<loc>".$this->baseurl.$item['loc']."</loc>\n";

      // lastmod
      if (!empty( $item['lastmod']))
        $content .= "\t\t\t<lastmod>{$item['lastmod']}</lastmod>\n";

      // changefreq
      if (!empty( $item['changefreq']))
        $content .= "\t\t\t<changefreq>{$item['changefreq']}</changefreq>\n";

      // priority
      if(!empty( $item['priority']))
        $content .= "\t\t\t<priority>{$item['priority']}</priority>\n";

      $content .= "\t\t</url>\n\n";

      if($count == $this->maxurls){
        $this->writeSitemap($content);
        $count = 1;
        $content = "";
      }
      $count++;
    }

    if($count != 1){
      //write remainer
      $this->writeSitemap($content);
    }
    
    $this->writeIndex();
    
    if($this->doPing){
      $this->pingSuccess = $this->ping();
    }
  }
  
  /**
  * Writes sitemap to file
  * @param string $string
  */
  function writeSitemap($string){
    $this->sitemaps++;

    $content = "<\x3Fxml version=\"1.0\" encoding=\"UTF-8\"\x3F>\n\t<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
    $content .= $string;
    $content .= "\t</urlset>\n";

    if($this->isGzip()){
      $ext = ".xml.gz";
      $content = gzencode($content, 1);
    } else {
      $ext = ".xml";
    }

    $f = fopen($this->basedir . "/" . $this->basefilename . $this->sitemaps . $ext, "w");
    fwrite($f, $content);
    fclose($f);
  }

  /**
  * Writes sitemap index to file
  */
  function writeIndex(){

    $content = "<\x3Fxml version=\"1.0\" encoding=\"UTF-8\"\x3F>\n\t<sitemapindex xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";

    $ext = $this->isGzip() ? ".xml.gz" : ".xml";

    for($i=1;$i<=$this->sitemaps;$i++){
      $content .= "<sitemap>\n".
      "\t<loc>".$this->baseurl . "/" . $this->basefilename . $i . $ext . "</loc>\n".
      "\t<lastmod>".date("c")."</lastmod>\n".
      "</sitemap>\n";
    }

    $content .= "</sitemapindex>";

    if($this->isGzip()){
      $content = gzencode($content, 1);
    }

    $f = fopen($this->basedir . "/" . $this->basefilename . "index" . $ext, "w");
    fwrite($f, $content);
    fclose($f);
  }
  
  /**
  * Pings Google
  * @return boolean $status
  */
  function ping(){
    $ext = $this->isGzip() ? ".xml.gz" : ".xml";
    
    $url = (strlen($this->sitemap_baseurl) > 0 ? $this->sitemap_baseurl : $this->baseurl) . "/" . $this->basefilename . "index" . $ext;
    $url = "http://www.google.com/webmasters/sitemaps/ping?sitemap=".urlencode($url);
    
    return $this->query_http($url);
  }
  
  /**
  * Shows some stats about the sitemaps
  * @return array $stats
  */
  function getStats(){
    $this->stats['no_urls'] = count($this->items);
    $this->stats['no_sitemaps'] = $this->sitemaps;
    $this->stats['successful_ping'] = $this->doPing ? $this->pingSuccess : "NA";
    $this->stats['sitemaps'] = array();
    
    for($i=1;$i<=$this->sitemaps;$i++){
      $ext = $this->isGzip() ? ".xml.gz" : ".xml";
      
      $this->stats['sitemaps'][] = (strlen($this->sitemap_baseurl) > 0 ? $this->sitemap_baseurl : $this->baseurl) . "/" . $this->basefilename . $i . $ext;
    }
    
    $this->stats['sitemap_index'] = (strlen($this->sitemap_baseurl) > 0 ? $this->sitemap_baseurl : $this->baseurl) . "/" . $this->basefilename . "index" . $ext;
    $this->stats['gzip_used'] = $this->isGzip();
    
    
    return $this->stats;
  }
}

/**
* Class for creating Yahoo! sitemaps
* Google and Yahoo! sitemaps are very similar, just have different ping urls
*/
class Yahoo_Sitemap extends Google_Sitemap{
  public $appid = ""; //To use the ping feature with Yahoo! you need to sign up for an application ID here: http://developer.yahoo.com/faq/index.html#appid (Required)
  
  /**
  * Pings Yahoo!
  * @return boolean $status
  */
  function ping(){
    $ext = $this->isGzip() ? ".xml.gz" : ".xml";
    $url = (strlen($this->sitemap_baseurl) > 0 ? $this->sitemap_baseurl : $this->baseurl) . "/" . $this->basefilename . "index" . $ext;
    $url = "http://search.yahooapis.com/SiteExplorerService/V1/updateNotification?appid=".$this->appid."&url=".urlencode($url);
    
    return $this->query_http($url);
  }
}

/**
* Class for generating basic text sitemap 
*/
class Text_Sitemap extends Sitemap{
  
  /**
  * Builds sitemap
  */
  function build(){
    $content = "";
    foreach($this->items as $item){
      $item['loc'] = htmlentities($item['loc'], ENT_QUOTES);
      $content .= $this->baseurl.$item['loc']."\n";
    }

    $this->writeSitemap($content);
  }
  
  /**
  * Writes sitemap to file
  */
  function writeSitemap($content){
    if($this->isGzip()){
      $ext = ".txt.gz";
      $content = gzencode($content, 1);
    } else {
      $ext = ".txt";
    }

    $f = fopen($this->basedir . $this->basefilename . "1" . $ext, "w");
    fwrite($f, $content);
    fclose($f);
  }
  
  /**
  * Shows some stats about the sitemaps
  * @return array $stats
  */
  function getStats(){
    $this->stats['no_urls'] = count($this->items);
    $this->stats['no_sitemaps'] = "1";
    $this->stats['sitemaps'] = array();
    
    $ext = $this->isGzip() ? ".txt.gz" : ".txt";
    
    $this->stats['sitemaps'][] = (strlen($this->sitemap_baseurl) > 0 ? $this->sitemap_baseurl : $this->baseurl) . "/" . $this->basefilename . "1" . $ext;
    
    $this->stats['gzip_used'] = $this->isGzip();
    
    return $this->stats;
  }
}
?>
