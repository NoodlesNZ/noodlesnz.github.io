<?
  if (ob_get_level() == 0) ob_start();
  
  $site = getRequestParameter("site", "www.noodles.net.nz");
  
  $link = mysql_connect('localhost', 'username', 'password')
     or die('Could not connect: ' . mysql_error());
  mysql_select_db('google') or die('Could not select database');
  
  $sql = "SELECT * FROM datacenters";
  $result = mysql_query($sql) or die('Query failed: ' . mysql_error());
  
  echo "<table cellpadding=5 border=1>
  <tr>
    <th>Datacenter</th>
    <th>Indexed Pages</th>
    <th>Backlinks</th>
  </tr>";
  while($row = mysql_fetch_array($result, MYSQL_ASSOC)){
    echo "<tr>";
    echo "<td>".$row['ip'] . "</td>";
    $content = @file_get_contents("http://{$row['ip']}/search?hl=en&q=site%3A{$site}&btnG=Google+Search");
    preg_match("/Results <b>.*?<\/b> - <b>.*?<\/b> of about <b>(.*?)<\/b>/i", $content, $matches);
    if(count($matches) > 0){
      echo "<td>".$matches[1]."</td>";
    } else {
      echo "<td>-</td>";
    }
    $content = @file_get_contents("http://{$row['ip']}/search?hl=en&q=link%3A{$site}&btnG=Google+Search");
    preg_match("/Results <b>.*?<\/b> - <b>.*?<\/b> of about <b>(.*?)<\/b>/i", $content, $matches);
    if(count($matches) > 0){
      echo "<td>".$matches[1]."</td>";
    } else {
      echo "<td>-</td>";
    }
    echo "</tr>";
    ob_flush();
    flush();
  }
  echo "</table>";
  
  function getRequestParameter($name, $default=null) {
    return array_key_exists($name, $_REQUEST) ? $_REQUEST[$name] : $default;
  }
?>
