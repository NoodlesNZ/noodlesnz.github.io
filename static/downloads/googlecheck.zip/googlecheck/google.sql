-- phpMyAdmin SQL Dump
-- version 2.6.3-pl1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Nov 02, 2006 at 03:03 AM
-- Server version: 5.0.21
-- PHP Version: 5.1.5
-- 
-- Database: `google`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `datacenters`
-- 

CREATE TABLE `datacenters` (
  `ipid` int(11) NOT NULL auto_increment,
  `ip` varchar(20) NOT NULL,
  PRIMARY KEY  (`ipid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=76 ;

-- 
-- Dumping data for table `datacenters`
-- 

INSERT INTO `datacenters` VALUES (1, '64.233.161.99');
INSERT INTO `datacenters` VALUES (2, '64.233.161.104');
INSERT INTO `datacenters` VALUES (3, '64.233.161.107');
INSERT INTO `datacenters` VALUES (4, '64.233.161.147');
INSERT INTO `datacenters` VALUES (5, '64.233.167.99');
INSERT INTO `datacenters` VALUES (6, '64.233.167.104');
INSERT INTO `datacenters` VALUES (7, '64.233.167.147');
INSERT INTO `datacenters` VALUES (8, '64.233.171.99');
INSERT INTO `datacenters` VALUES (9, '64.233.171.104');
INSERT INTO `datacenters` VALUES (10, '64.233.171.107');
INSERT INTO `datacenters` VALUES (11, '64.233.171.147');
INSERT INTO `datacenters` VALUES (12, '64.233.179.99');
INSERT INTO `datacenters` VALUES (13, '64.233.179.104');
INSERT INTO `datacenters` VALUES (14, '64.233.179.107');
INSERT INTO `datacenters` VALUES (15, '64.233.183.99');
INSERT INTO `datacenters` VALUES (16, '64.233.183.104');
INSERT INTO `datacenters` VALUES (17, '64.233.183.107');
INSERT INTO `datacenters` VALUES (18, '64.233.185.99');
INSERT INTO `datacenters` VALUES (19, '64.233.185.104');
INSERT INTO `datacenters` VALUES (20, '64.233.187.99');
INSERT INTO `datacenters` VALUES (21, '64.233.187.104');
INSERT INTO `datacenters` VALUES (22, '64.233.187.107');
INSERT INTO `datacenters` VALUES (23, '64.233.189.104');
INSERT INTO `datacenters` VALUES (24, '66.102.7.99');
INSERT INTO `datacenters` VALUES (25, '66.102.7.104');
INSERT INTO `datacenters` VALUES (26, '66.102.7.147');
INSERT INTO `datacenters` VALUES (27, '66.102.9.99');
INSERT INTO `datacenters` VALUES (28, '66.102.9.104');
INSERT INTO `datacenters` VALUES (29, '66.102.9.107');
INSERT INTO `datacenters` VALUES (30, '66.102.9.147');
INSERT INTO `datacenters` VALUES (31, '66.102.11.99');
INSERT INTO `datacenters` VALUES (32, '66.102.11.104');
INSERT INTO `datacenters` VALUES (33, '66.102.11.107');
INSERT INTO `datacenters` VALUES (34, '66.249.85.99');
INSERT INTO `datacenters` VALUES (35, '66.249.85.104');
INSERT INTO `datacenters` VALUES (36, '66.249.85.107');
INSERT INTO `datacenters` VALUES (37, '66.249.93.99');
INSERT INTO `datacenters` VALUES (38, '66.249.93.104');
INSERT INTO `datacenters` VALUES (39, '66.249.93.107');
INSERT INTO `datacenters` VALUES (40, '72.14.203.99');
INSERT INTO `datacenters` VALUES (41, '72.14.203.104');
INSERT INTO `datacenters` VALUES (42, '72.14.203.107');
INSERT INTO `datacenters` VALUES (43, '72.14.205.99');
INSERT INTO `datacenters` VALUES (44, '72.14.205.104');
INSERT INTO `datacenters` VALUES (45, '72.14.205.107');
INSERT INTO `datacenters` VALUES (46, '72.14.207.99');
INSERT INTO `datacenters` VALUES (47, '72.14.207.104');
INSERT INTO `datacenters` VALUES (48, '72.14.207.107');
INSERT INTO `datacenters` VALUES (49, '72.14.209.99');
INSERT INTO `datacenters` VALUES (50, '72.14.209.104');
INSERT INTO `datacenters` VALUES (51, '72.14.209.107');
INSERT INTO `datacenters` VALUES (52, '216.239.37.99');
INSERT INTO `datacenters` VALUES (53, '216.239.37.104');
INSERT INTO `datacenters` VALUES (54, '216.239.37.107');
INSERT INTO `datacenters` VALUES (55, '216.239.39.99');
INSERT INTO `datacenters` VALUES (56, '216.239.39.104');
INSERT INTO `datacenters` VALUES (57, '216.239.39.107');
INSERT INTO `datacenters` VALUES (58, '216.239.51.99');
INSERT INTO `datacenters` VALUES (59, '216.239.51.104');
INSERT INTO `datacenters` VALUES (60, '216.239.51.107');
INSERT INTO `datacenters` VALUES (61, '216.239.53.99');
INSERT INTO `datacenters` VALUES (62, '216.239.53.104');
INSERT INTO `datacenters` VALUES (63, '216.239.53.107');
INSERT INTO `datacenters` VALUES (64, '216.239.57.99');
INSERT INTO `datacenters` VALUES (65, '216.239.57.103');
INSERT INTO `datacenters` VALUES (66, '216.239.57.104');
INSERT INTO `datacenters` VALUES (67, '216.239.57.107');
INSERT INTO `datacenters` VALUES (68, '216.239.57.147');
INSERT INTO `datacenters` VALUES (69, '216.239.59.99');
INSERT INTO `datacenters` VALUES (70, '216.239.59.103');
INSERT INTO `datacenters` VALUES (71, '216.239.59.104');
INSERT INTO `datacenters` VALUES (72, '216.239.59.107');
INSERT INTO `datacenters` VALUES (73, '216.239.59.147');
INSERT INTO `datacenters` VALUES (74, '216.239.63.99');
INSERT INTO `datacenters` VALUES (75, '216.239.63.104');
