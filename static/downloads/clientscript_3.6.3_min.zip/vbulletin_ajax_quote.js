
var quote_editorid;var quote_xml;function init_unquoted_posts(editorid,threadid)
{var fetch_link=fetch_object('multiquote_more');if(fetch_link)
{fetch_link.onclick=function(){return handle_unquoted_posts(editorid,threadid,'fetch');};}
var deselect_link=fetch_object('multiquote_deselect');if(deselect_link)
{deselect_link.onclick=function(){return handle_unquoted_posts(editorid,threadid,'deselect');};}}
function handle_unquoted_posts(editorid,threadid,type)
{quote_editorid=editorid;quote_xml=new vB_AJAX_Handler(true);quote_xml.onreadystatechange(handle_ajax_unquoted_response);quote_xml.send('newreply.php?do=unquotedposts&threadid='+threadid,'do=unquotedposts&threadid='+threadid
+'&wysiwyg='+(vB_Editor[quote_editorid].wysiwyg_mode?1:0)
+'&type='+PHP.urlencode(type));return false;}
function handle_ajax_unquoted_response()
{if(quote_xml.handler.readyState==4&&quote_xml.handler.status==200)
{if(quote_xml.handler.responseXML)
{if(fetch_tags(quote_xml.handler.responseXML,'quotes')[0])
{vB_Editor[quote_editorid].history.add_snapshot(vB_Editor[quote_editorid].get_editor_contents());vB_Editor[quote_editorid].insert_text(quote_xml.fetch_data(fetch_tags(quote_xml.handler.responseXML,'quotes')[0]));vB_Editor[quote_editorid].collapse_selection_end();vB_Editor[quote_editorid].history.add_snapshot(vB_Editor[quote_editorid].get_editor_contents());var multiquote_empty_input=fetch_object('multiquote_empty_input');if(multiquote_empty_input)
{multiquote_empty_input.value='all';}}
else if(fetch_tags(quote_xml.handler.responseXML,'mqpostids')[0])
{set_cookie('vbulletin_multiquote',quote_xml.fetch_data(fetch_tags(quote_xml.handler.responseXML,'mqpostids')[0]));}
var unquoted_posts=fetch_object('unquoted_posts');if(unquoted_posts)
{unquoted_posts.style.display='none';}}
if(is_ie)
{quote_xml.handler.abort();}}}