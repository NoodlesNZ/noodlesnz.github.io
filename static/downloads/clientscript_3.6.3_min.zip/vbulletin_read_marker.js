
var vB_ReadMarker=new Array()
var vB_ReadMarker={'forum_statusicon_prefix':'forum_statusicon_','thread_statusicon_prefix':'thread_statusicon_','thread_gotonew_prefix':'thread_gotonew_','thread_title_prefix':'thread_title_'};function vB_AJAX_ReadMarker(forumid)
{this.forumid=forumid;};vB_AJAX_ReadMarker.prototype.mark_read=function()
{forumid=this.forumid;this.ajax=new vB_AJAX_Handler(true);this.ajax.onreadystatechange(vB_ReadMarker[forumid].ajax_check);this.ajax.send('ajax.php?do=markread&f='+this.forumid,'do=markread&forumid='+this.forumid);};vB_AJAX_ReadMarker.prototype.ajax_check=function()
{var AJAX=vB_ReadMarker[forumid].ajax.handler;if(AJAX.readyState==4&&AJAX.status==200)
{if(AJAX.responseXML)
{vB_ReadMarker[forumid].handle_forums_xml(AJAX.responseXML);}
if(is_ie)
{AJAX.abort();}}
return false;};vB_AJAX_ReadMarker.prototype.handle_forums_xml=function(forums_xml)
{var forum_nodes=fetch_tags(forums_xml,'forum');for(var i=0;i<forum_nodes.length;i++)
{var forumid=this.ajax.fetch_data(forum_nodes[i]);this.update_forum_status(forumid);var threadbits_object=fetch_object('threadbits_forum_'+forumid);if(threadbits_object)
{this.handle_threadbits(threadbits_object);}}};vB_AJAX_ReadMarker.prototype.update_forum_status=function(forumid)
{var imageobj=fetch_object(vB_ReadMarker['forum_statusicon_prefix']+forumid);if(imageobj)
{imageobj.style.cursor='default';imageobj.title=imageobj.otitle;imageobj.src=this.fetch_old_src(imageobj.src,'forum');}};vB_AJAX_ReadMarker.prototype.handle_threadbits=function(threadbits_object)
{var links=fetch_tags(threadbits_object,'a');for(var i=0;i<links.length;i++)
{if(links[i].id&&links[i].id.substr(0,vB_ReadMarker['thread_gotonew_prefix'].length)==vB_ReadMarker['thread_gotonew_prefix'])
{this.update_thread_status(links[i].id.substr(vB_ReadMarker['thread_gotonew_prefix'].length));}}};vB_AJAX_ReadMarker.prototype.update_thread_status=function(threadid)
{var statusicon=fetch_object(vB_ReadMarker['thread_statusicon_prefix']+threadid);if(statusicon)
{statusicon.src=this.fetch_old_src(statusicon.src,'thread');}
var gotonew=fetch_object(vB_ReadMarker['thread_gotonew_prefix']+threadid);if(gotonew)
{gotonew.parentNode.removeChild(gotonew);}
var threadtitle=fetch_object(vB_ReadMarker['thread_title_prefix']+threadid);if(threadtitle)
{threadtitle.style.fontWeight='normal';}};vB_AJAX_ReadMarker.prototype.fetch_old_src=function(newsrc,type)
{var foo=newsrc.replace(/_(new)([\._])(.+)$/i,(type=='thread'?'$2$3':'_old$2$3'));return foo;};function mark_forum_read(forumid)
{if(AJAX_Compatible)
{vB_ReadMarker[forumid]=new vB_AJAX_ReadMarker(forumid);vB_ReadMarker[forumid].mark_read();}
else
{window.location='forumdisplay.php?'+SESSIONURL+'do=markread&forumid='+forumid;}
return false;};function init_forum_readmarker_icon(e)
{mark_forum_read(this.id.substr(vB_ReadMarker['forum_statusicon_prefix'].length));};function init_forum_readmarker_system()
{var images=fetch_tags(document,'img');for(var i=0;i<images.length;i++)
{if(images[i].id&&images[i].id.substr(0,vB_ReadMarker['forum_statusicon_prefix'].length)==vB_ReadMarker['forum_statusicon_prefix'])
{if(images[i].src.search(/\/([^\/]+)(new)(_lock)?\.([a-z0-9]+)$/i)!=-1)
{img_alt_2_title(images[i]);images[i].otitle=images[i].title;images[i].title=vbphrase['doubleclick_forum_markread'];images[i].style.cursor=pointer_cursor;images[i].ondblclick=init_forum_readmarker_icon;}}}};