
var activeElementId=0;var colorPickerType=0;var pickerReady=false;var colors=new Array("00","33","66","99","CC","FF");var specialColors=new Array('#000000','#333333','#666666','#999999','#CCCCCC','#FFFFFF','#FF0000','#00FF00','#0000FF','#FFFF00','#00FFFF','#FF00FF');function init_color_preview()
{if(typeof(numColors)!="undefined")
{for(var i=0;i<numColors;i++)
{preview_color(i);}
if(colorPickerType!=0)
{init_color_picker(colorPickerType);}
pickerReady=true;}}
function preview_color(elm)
{var colorElement=fetch_object("color_"+elm);var previewElement=fetch_object("preview_"+elm);var cssRegExp=new RegExp(/url\(('|"|)((http:\/\/|\/)?)(.*)\1\)/i);if(is_transparent(colorElement.value))
{previewElement.style.background="none";previewElement.style.borderStyle="dashed";previewElement.title=window.status="";}
else
{var cssValue=colorElement.value;var matches;if(matches=colorElement.value.match(cssRegExp))
{if(typeof matches[3]=="undefined"||matches[3]=="")
{cssValue=colorElement.value.replace(matches[4],(bburl+matches[4]));}}
try
{previewElement.style.background=cssValue;previewElement.style.borderStyle="inset";previewElement.title=window.status="";}
catch(csserror)
{previewElement.style.background="url('../cpstyles/"+cpstylefolder+"/cp_help.gif') no-repeat center";previewElement.style.borderStyle="dashed";previewElement.title=window.status=construct_phrase(vbphrase["css_value_invalid"],cssValue);}}}
function set_swatch_color(x,y,color)
{fetch_object("sw"+x+"-"+y).style.backgroundColor=color;}
function init_color_picker(setPickerType)
{colorPickerType=setPickerType;fetch_object("colorPickerType").value=setPickerType;var y,x,i,j;if(setPickerType<2)
{for(y=0;y<12;y++)
{set_swatch_color(0,y,'#000000');set_swatch_color(1,y,specialColors[y]);set_swatch_color(2,y,'#000000');}}
switch(setPickerType)
{case 0:{green=new Array(5,4,3,2,1,0,0,1,2,3,4,5);blue=new Array(0,0,0,5,4,3,2,1,0,0,1,2,3,4,5,5,4,3,2,1,0);for(y=0;y<12;y++)
{for(x=3;x<21;x++)
{r=Math.floor((20-x)/6)*2+Math.floor(y/6);g=green[y];b=blue[x];set_swatch_color(x,y,"#"+colors[r]+colors[g]+colors[b]);}}}
break;case 1:{green=new Array(0,0,0,0,1,2,3,4,5,0,1,2,3,4,5,0,1,2,3,4,5);blue=new Array(0,1,2,3,4,5,0,1,2,3,4,5);for(y=0;y<12;y++)
{for(x=3;x<21;x++)
{r=Math.floor((x-3)/6)+Math.floor(y/6)*3;g=green[x];b=blue[y];set_swatch_color(x,y,"#"+colors[r]+colors[g]+colors[b]);}}}
break;case 2:{i=255;j=-1;for(y=0;y<12;y++)
{for(x=0;x<21;x++)
{set_swatch_color(x,y,"rgb("+i+","+i+","+i+")");i--;if(i==4)
{i=0;}}}}
break;case 3:case 4:case 5:case 6:case 7:case 8:{i=255;j=255;for(y=0;y<12;y++)
{for(x=0;x<21;x++)
{acolor=Math.round(j);bcolor=Math.round(i);if(acolor<0)
{acolor=0;}
switch(setPickerType)
{case 3:r=acolor;g=bcolor;b=bcolor;break;case 4:r=bcolor;g=acolor;b=bcolor;break;case 5:r=bcolor;g=bcolor;b=acolor;break;case 6:r=acolor;g=acolor;b=bcolor;break;case 7:r=acolor;g=bcolor;b=acolor;break;case 8:r=bcolor;g=acolor;b=acolor;break;}
set_swatch_color(x,y,"rgb("+r+","+g+","+b+")");if(i>1)
{i-=2.03174;}
else
{i=0;if(j>1.03)
{j-=2.03174;}}}}}
break;default:return false;}
pickerReady=true;return true;}
function switch_color_picker(direction)
{if(direction>0)
{if(colorPickerType<8)
{colorPickerType++;}
else
{colorPickerType=0;}}
else
{if(colorPickerType>0)
{colorPickerType--;}
else
{colorPickerType=8;}}
init_color_picker(colorPickerType);}
function open_color_picker(clickedElementId,e)
{if(!pickerReady)
{alert(vbphrase["color_picker_not_ready"]);return;}
pickerElement=fetch_object("colorPicker");if(activeElementId==clickedElementId&&pickerElement.style.display!="none")
{pickerElement.style.display="none";}
else
{activeElementId=clickedElementId;colorElement=fetch_object("color_"+clickedElementId);previewElement=fetch_object("preview_"+clickedElementId);var thecolor=null;if(previewElement.style.background)
{thecolor=previewElement.style.backgroundColor;}
else
{thecolor=previewElement.style.backgroundColor;}
fetch_object("oldColor").style.background=thecolor;fetch_object("newColor").style.background=thecolor;fetch_object("txtColor").value=colorElement.value;if(!e)
{e=window.event;}
if(typeof(e.pageX)=="number")
{xpos=e.pageX;ypos=e.pageY;}
else if(typeof(e.clientX)=="number")
{xpos=e.clientX+document.documentElement.scrollLeft;ypos=e.clientY+document.documentElement.scrollTop;}
xpos+=10;ypos+=5;if((xpos+colorPickerWidth)>=document.body.clientWidth)
{xpos=document.body.clientWidth-colorPickerWidth-5;}
pickerElement.style.left=xpos+"px";pickerElement.style.top=ypos+"px";pickerElement.style.display="";}}
function close_color_picker()
{activeElementId=0;fetch_object("colorPicker").style.display="none";}
function swatch_over(e)
{col_over(this);}
function swatch_click(e)
{col_click(this);}
function col_over(element)
{color=fetch_hex_color(element.style.backgroundColor);fetch_object("newColor").style.background=color;fetch_object("txtColor").value=color;}
function col_click(element)
{if(element=="transparent")
{color=element;}
else
{color=fetch_hex_color(element.style.backgroundColor);}
fetch_object("color_"+activeElementId).value=color;preview_color(activeElementId);close_color_picker();}
function fetch_hex_color(color)
{if(color.substr(0,1)=="r")
{colorMatch=color.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/i);for(var i=1;i<4;i++)
{colorMatch[i]=parseInt(colorMatch[i]).toString(16);if(colorMatch[i].length<2)
{colorMatch[i]="0"+colorMatch[i];}}
color="#"+(colorMatch[1]+colorMatch[2]+colorMatch[3]).toUpperCase();}
return color.toUpperCase();}
function is_transparent(value)
{if(value==""||value=="none"||value=="transparent")
{return true;}
else
{return false;}}