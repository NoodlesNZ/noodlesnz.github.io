
function vB_AJAX_Userlist_Init(ignoreformid,buddyformid)
{if(AJAX_Compatible&&(typeof vb_disable_ajax=='undefined'||vb_disable_ajax==0))
{if(typeof(document.forms.userlist_buddyform)!='undefined')
{document.forms.userlist_buddyform.onsubmit=vB_AJAX_Userlist.prototype.form_click;}
if(typeof(document.forms.userlist_ignoreform)!='undefined')
{document.forms.userlist_ignoreform.onsubmit=vB_AJAX_Userlist.prototype.form_click;}}};function vB_AJAX_Userlist(formobj)
{this.xml_sender=null;this.pseudoform=new vB_Hidden_Form('profile.php');this.pseudoform.add_variable('ajax',1);this.pseudoform.add_variables_from_object(formobj);this.list=this.pseudoform.fetch_variable('userlist');var me=this;this.handle_ajax_response=function()
{if(me.xml_sender.handler.readyState==4&&me.xml_sender.handler.status==200)
{if(me.xml_sender.handler.responseXML)
{var error=me.xml_sender.fetch_data(fetch_tags(me.xml_sender.handler.responseXML,'error')[0]);if(error)
{fetch_object('userfield_'+me.list+'_errortext').innerHTML=error;fetch_object('userfield_'+me.list+'_error').style.display='';}
else
{fetch_object('userfield_'+me.list+'_error').style.display='none';fetch_object('userfield_'+me.list+'_txt').value='';fetch_object(me.list+'list1').innerHTML=me.xml_sender.fetch_data(fetch_tags(me.xml_sender.handler.responseXML,'listbit1')[0]);fetch_object(me.list+'list2').innerHTML=me.xml_sender.fetch_data(fetch_tags(me.xml_sender.handler.responseXML,'listbit2')[0]);}}
if(is_ie)
{me.xml_sender.handler.abort();}}}};vB_AJAX_Userlist.prototype.submit=function()
{this.xml_sender=new vB_AJAX_Handler(true);this.xml_sender.onreadystatechange(this.handle_ajax_response);this.xml_sender.send('profile.php?do=updatelist&userlist='+PHP.urlencode(this.list),this.pseudoform.build_query_string());};vB_AJAX_Userlist.prototype.form_click=function()
{var AJAX_Userlist=new vB_AJAX_Userlist(this);AJAX_Userlist.submit();return false;};