
var vB_ThreadTitle_Editor=null;function vB_AJAX_Threadlist_Init(threadlistid)
{if(AJAX_Compatible&&(typeof vb_disable_ajax=='undefined'||vb_disable_ajax<2))
{var tds=fetch_tags(fetch_object(threadlistid),'td');for(var i=0;i<tds.length;i++)
{if(tds[i].hasChildNodes()&&tds[i].id&&tds[i].id.substr(0,3)=='td_')
{var anchors=fetch_tags(tds[i],'a');for(var j=0;j<anchors.length;j++)
{if(anchors[j].name&&anchors[j].name.indexOf('vB::AJAX')!=-1)
{var details=tds[i].id.split('_');switch(details[1])
{case'threadtitle':{if(typeof vb_disable_ajax=='undefined'||vb_disable_ajax==0)
{tds[i].style.cursor='default';tds[i].ondblclick=vB_AJAX_ThreadList_Events.prototype.threadtitle_doubleclick;}}
break;case'threadstatusicon':{tds[i].style.cursor=pointer_cursor;tds[i].ondblclick=vB_AJAX_ThreadList_Events.prototype.threadicon_doubleclick;}
break;}
break;}}}}}}
function vB_AJAX_OpenClose(obj)
{this.obj=obj;this.threadid=this.obj.id.substr(this.obj.id.lastIndexOf('_')+1);this.imgobj=fetch_object('thread_statusicon_'+this.threadid);this.xml_sender=null;this.toggle=function()
{this.xml_sender=new vB_AJAX_Handler(true);this.xml_sender.onreadystatechange(this.onreadystatechange);this.xml_sender.send('ajax.php?do=updatethreadopen&t='+this.threadid,'do=updatethreadopen&t='+this.threadid+'&src='+PHP.urlencode(this.imgobj.src));}
var me=this;this.onreadystatechange=function()
{if(me.xml_sender.handler.readyState==4&&me.xml_sender.handler.status==200)
{if(me.xml_sender.handler.responseXML)
{me.imgobj.src=me.xml_sender.fetch_data(fetch_tags(me.xml_sender.handler.responseXML,'imagesrc')[0]);if(iobj=fetch_object("tlist_"+me.threadid))
{if(me.imgobj.src.indexOf('_lock')!=-1)
{iobj.value=iobj.value|1;}
else
{iobj.value=iobj.value&~1;}}}
if(is_ie)
{me.xml_sender.handler.abort();}}}
this.toggle();}
function vB_AJAX_TitleEdit(obj)
{this.obj=obj;this.threadid=this.obj.id.substr(this.obj.id.lastIndexOf('_')+1);this.linkobj=fetch_object('thread_title_'+this.threadid);this.container=this.linkobj.parentNode;this.editobj=null;this.xml_sender=null;this.origtitle='';this.editstate=false;this.edit=function()
{if(this.editstate==false)
{this.inputobj=document.createElement('input');this.inputobj.type='text';this.inputobj.size=50;this.inputobj.maxLength=85;this.inputobj.style.width=Math.max(this.linkobj.offsetWidth,250)+'px';this.inputobj.className='bginput';this.inputobj.value=PHP.unhtmlspecialchars(this.linkobj.innerHTML);this.inputobj.title=this.inputobj.value;this.inputobj.onblur=vB_AJAX_ThreadList_Events.prototype.titleinput_onblur;this.inputobj.onkeypress=vB_AJAX_ThreadList_Events.prototype.titleinput_onkeypress;this.editobj=this.container.insertBefore(this.inputobj,this.linkobj);this.editobj.select();this.origtitle=this.linkobj.innerHTML;this.linkobj.style.display='none';this.editstate=true;}}
this.restore=function()
{if(this.editstate==true)
{if(this.editobj.value!=this.origtitle)
{this.linkobj.innerHTML=PHP.htmlspecialchars(this.editobj.value);this.save(this.editobj.value);}
else
{this.linkobj.innerHTML=this.editobj.value;}
this.container.removeChild(this.editobj);this.linkobj.style.display='';this.editstate=false;this.obj=null;}}
this.save=function(titletext)
{this.xml_sender=new vB_AJAX_Handler(true);this.xml_sender.onreadystatechange(this.onreadystatechange);this.xml_sender.send('ajax.php?do=updatethreadtitle&t='+this.threadid,'do=updatethreadtitle&t='+this.threadid+'&title='+PHP.urlencode(titletext));}
var me=this;this.onreadystatechange=function()
{if(me.xml_sender.handler.readyState==4&&me.xml_sender.handler.status==200)
{if(me.xml_sender.handler.responseXML)
{me.linkobj.innerHTML=me.xml_sender.fetch_data(fetch_tags(me.xml_sender.handler.responseXML,'linkhtml')[0]);}
if(is_ie)
{me.xml_sender.handler.abort();}
vB_ThreadTitle_Editor.obj=null;}}
this.edit();}
function vB_AJAX_ThreadList_Events()
{}
vB_AJAX_ThreadList_Events.prototype.threadtitle_doubleclick=function(e)
{if(vB_ThreadTitle_Editor&&vB_ThreadTitle_Editor.obj==this)
{return false;}
else
{try
{vB_ThreadTitle_Editor.restore();}
catch(e){}
vB_ThreadTitle_Editor=new vB_AJAX_TitleEdit(this);}};vB_AJAX_ThreadList_Events.prototype.threadicon_doubleclick=function(e)
{openclose=new vB_AJAX_OpenClose(this);};vB_AJAX_ThreadList_Events.prototype.titleinput_onblur=function(e)
{vB_ThreadTitle_Editor.restore();};vB_AJAX_ThreadList_Events.prototype.titleinput_onkeypress=function(e)
{e=e?e:window.event;switch(e.keyCode)
{case 13:{vB_ThreadTitle_Editor.inputobj.blur();return false;}
case 27:{vB_ThreadTitle_Editor.inputobj.value=vB_ThreadTitle_Editor.origtitle;vB_ThreadTitle_Editor.inputobj.blur();return true;}}};