
var qr_repost=false;var qr_errors_shown=false;var qr_active=false;var qr_posting=0;var clickedelm=false;function qr_init()
{qr_disable_controls();qr_init_buttons(fetch_object('posts'));}
function qr_init_buttons(obj)
{var anchors=fetch_tags(obj,'a');for(var i=0;i<anchors.length;i++)
{if(anchors[i].id&&anchors[i].id.substr(0,3)=='qr_')
{anchors[i].onclick=function(e){return qr_activate(this.id.substr(3));};}}}
function qr_disable_controls()
{if(require_click)
{fetch_object('qr_postid').value=0;vB_Editor[QR_EditorID].disable_editor(vbphrase['click_quick_reply_icon']);var qr_sig=fetch_object('cb_signature');if(qr_sig!=null)
{qr_sig.disabled=true;}
active=false;}
else
{vB_Editor[QR_EditorID].write_editor_contents('');}
if(threaded_mode!=1)
{fetch_object('qr_quickreply').disabled=true;}
qr_active=false;}
function qr_activate(postid)
{var qr_collapse=fetch_object('collapseobj_quickreply');if(qr_collapse&&qr_collapse.style.display=="none")
{toggle_collapse('quickreply');}
fetch_object('qr_postid').value=postid;fetch_object('qr_preview').select();fetch_object('qr_quickreply').disabled=false;var qr_sig=fetch_object("cb_signature");if(qr_sig)
{qr_sig.disabled=false;qr_sig.checked=true;}
if(qr_active==false)
{vB_Editor[QR_EditorID].enable_editor('');}
if(!is_ie&&vB_Editor[QR_EditorID].wysiwyg_mode)
{fetch_object('qr_scroll').scrollIntoView(false);}
vB_Editor[QR_EditorID].check_focus();qr_active=true;return false;}
function qr_prepare_submit(formobj,minchars)
{if(qr_repost==true)
{return true;}
if(!allow_ajax_qr||!AJAX_Compatible)
{return qr_check_data(formobj,minchars);}
else if(qr_check_data(formobj,minchars))
{var test_ajax=new vB_AJAX_Handler(true);if(!test_ajax.init()||(typeof vb_disable_ajax!='undefined'&&vb_disable_ajax>0))
{return true;}
if(is_ie&&userAgent.indexOf('msie 5.')!=-1)
{if(PHP.urlencode(formobj.message.value).indexOf('%u')!=-1)
{return true;}}
if(qr_posting==1)
{return false;}
else
{qr_posting=1;setTimeout("qr_posting = 0",1000);}
if(clickedelm==formobj.preview.value)
{return true;}
else
{var submitstring='ajax=1';if(typeof ajax_last_post!='undefined')
{submitstring+='&ajax_lastpost='+PHP.urlencode(ajax_last_post);}
for(i=0;i<formobj.elements.length;i++)
{var obj=formobj.elements[i];if(obj.name&&!obj.disabled)
{switch(obj.type)
{case'text':case'textarea':case'hidden':submitstring+='&'+obj.name+'='+PHP.urlencode(obj.value);break;case'checkbox':case'radio':submitstring+=obj.checked?'&'+obj.name+'='+PHP.urlencode(obj.value):'';break;case'select':submitstring+='&'+obj.name+'='+PHP.urlencode(obj.options[obj.selectedIndex].value);break;}}}
fetch_object('qr_posting_msg').style.display='';document.body.style.cursor='wait';qr_ajax_post(formobj.action,submitstring);return false;}}
else
{return false;}}
function qr_check_data(formobj,minchars)
{switch(fetch_object('qr_postid').value)
{case'0':{alert(vbphrase['click_quick_reply_icon']);return false;}
case'who cares':{if(typeof formobj.quickreply!='undefined')
{formobj.quickreply.checked=false;}
break;}}
if(clickedelm==formobj.preview.value)
{minchars=0;}
return vB_Editor[QR_EditorID].prepare_submit(0,minchars);}
function qr_ajax_post(submitaction,submitstring)
{qr_repost=false;xml=new vB_AJAX_Handler(true);xml.onreadystatechange(qr_do_ajax_post);xml.send(submitaction,submitstring);}
function qr_do_ajax_post()
{if(xml.handler.readyState==4&&xml.handler.status==200)
{if(xml.handler.responseXML)
{document.body.style.cursor='auto';fetch_object('qr_posting_msg').style.display='none';qr_posting=0;if(fetch_tag_count(xml.handler.responseXML,'postbit'))
{ajax_last_post=xml.fetch_data(fetch_tags(xml.handler.responseXML,'time')[0]);qr_disable_controls();qr_hide_errors();var postbits=fetch_tags(xml.handler.responseXML,'postbit');for(var i=0;i<postbits.length;i++)
{var newdiv=document.createElement('div');newdiv.innerHTML=xml.fetch_data(postbits[i]);var lp=fetch_object('lastpost');var lpparent=lp.parentNode;var postbit=lpparent.insertBefore(newdiv,lp);PostBit_Init(postbit,postbits[i].getAttribute('postid'));}
if(fetch_object('qr_submit'))
{fetch_object('qr_submit').blur();}}
else
{if(!is_saf)
{var errors=fetch_tags(xml.handler.responseXML,'error');var error_html='<ol>';for(var i=0;i<errors.length;i++)
{error_html+='<li>'+xml.fetch_data(errors[i])+'</li>';}
error_html+='</ol>';qr_show_errors('<ol>'+error_html+'</ol>');if(is_ie)
{xml.handler.abort();}
return false;}
qr_repost=true;fetch_object('qrform').submit();}}
else
{qr_repost=true;fetch_object('qrform').submit();}
if(is_ie)
{xml.handler.abort();}}}
function qr_show_errors(errortext)
{qr_errors_shown=true;fetch_object('qr_error_td').innerHTML=errortext;fetch_object('qr_error_tbody').style.display='';vB_Editor[QR_EditorID].check_focus();return false;}
function qr_hide_errors()
{if(qr_errors_shown)
{qr_errors_shown=true;fetch_object('qr_error_tbody').style.display='none';return false;}}
var vB_QuickReply=true;