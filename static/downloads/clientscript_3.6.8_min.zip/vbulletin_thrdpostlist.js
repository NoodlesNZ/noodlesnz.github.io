
if(document.all&&navigator.appVersion.charAt(navigator.appVersion.indexOf("MSIE")+5)>=5&&navigator.userAgent.toLowerCase().indexOf('opera')==-1)
{ie5=true;}
else
{ie5=false;}
var pd=new Array();var pn=new Array();var pu=new Array();var imgStringCache=new Array();var imgCache=new Array();if(document.dir=='rtl')
{imgCache={"I":'<img src="'+imgdir_misc+'/tree_ir.gif" alt="" />',"L":'<img src="'+imgdir_misc+'/tree_rtl.gif" alt="" />',"T":'<img src="'+imgdir_misc+'/tree_tr.gif" alt="" />'};}
else
{imgCache={"I":'<img src="'+imgdir_misc+'/tree_i.gif" alt="" />',"L":'<img src="'+imgdir_misc+'/tree_ltr.gif" alt="" />',"T":'<img src="'+imgdir_misc+'/tree_t.gif" alt="" />'};}
function showPrevNextPost(nextOrPrev)
{info=pn[curpostid].split(',');showPost(info[nextOrPrev]);}
function setQRpostid(postid)
{if(quickreply)
{fetch_object("qr_postid").value=postid;}}
function navToPost(postid,noreload)
{if(postid!=0&&!noreload)
{window.location="showthread.php?"+SESSIONURL+"p="+postid+"#poststop";}}
function showPost(postid,noreload)
{if(typeof pd[postid]!='undefined')
{try
{if(quickreply)
{fetch_object("qr_postid").value=postid;}
fetch_object("link"+curpostid).style.fontWeight="normal";fetch_object("div"+curpostid).className='alt1';fetch_object("link"+postid).style.fontWeight="bold";fetch_object("div"+postid).className='alt2';try
{fetch_object("links").scrollIntoView(true);}
catch(e)
{}
fetch_object("posts").innerHTML=pd[postid];FIRSTPOSTID=postid;LASTPOSTID=postid;}
catch(e)
{navToPost(postid,noreload);}}
else
{navToPost(postid,noreload);}
curpostid=postid;return false;}
function writeLink(postid,isnew,attachment,userid,imgString,title,datestring,timestring,doshowpost)
{if(postid==curpostid||doshowpost)
{bgclass='alt2';}
else
{bgclass='alt1';}
document.write('<div class="'+bgclass+'" id="div'+postid+'">');if(!imgStringCache[imgString])
{imgStringCache[imgString]="";imgArray=imgString.split(',');for(i in imgArray)
{curType=imgArray[i];if(isNaN(curType))
{imgStringCache[imgString]+=imgCache[curType];}
else
{imgStringCache[imgString]+='<img src="'+cleargifurl+'" width="'+(curType*20)+'" height="20" alt="" />';}}}
document.write(imgStringCache[imgString]);if(isnew==1)
{statusicon='new';}
else
{statusicon='old';}
document.write('<img src="'+imgdir_statusicon+'/post_'+statusicon+'.gif" alt="" /> ');if(datestring=='more')
{document.write('<a href="showthread.php?p='+postid+highlightwords+'#post'+postid+'" id="link'+postid+'"><i>'+morephrase+'</i></a></div>\n');}
else
{if(attachment==1)
{document.write('<img src="'+imgdir_misc+'/paperclip.gif" alt="PaperClip" title="Attachment" /> ');}
if(typeof pu[userid]!="undefined")
{document.write(pu[userid].bold()+' ');}
else
{document.write(guestphrase+" ");}
if(postid==curpostid)
{titlestyle=' style="font-weight:bold;"';}
else
{titlestyle='';}
document.write('<a href="showthread.php?p='+postid+highlightwords+'#post'+postid+'" onclick="return showPost('+postid+')" id="link'+postid+'"'+titlestyle+'>'+title+'</a> ');if(ie5&&typeof pd[postid]!="undefined")
{iscached='.';}
else
{iscached='';}
document.write(datestring+', <span class="time">'+timestring+iscached+'</span>');document.write('</div>\n');}}