
function vB_AJAX_WolResolve_Init(woltableid)
{if(AJAX_Compatible&&(typeof vb_disable_ajax=='undefined'||vb_disable_ajax<2))
{var link_list=fetch_tags(fetch_object(woltableid),'a');for(var i=0;i<link_list.length;i++)
{if(link_list[i].id&&link_list[i].id.substr(0,10)=='resolveip_'&&link_list[i].innerHTML.match(/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/))
{link_list[i].onclick=resolve_ip_click;}}}}
function vB_AJAX_WolResolve(ip,objid)
{this.ip=ip;this.objid=objid;this.xml_sender=null;var me=this;this.resolve=function()
{this.xml_sender=new vB_AJAX_Handler(true);this.xml_sender.onreadystatechange(this.onreadystatechange);this.xml_sender.send('online.php?do=resolveip&ipaddress='+PHP.urlencode(this.ip),'do=resolveip&ajax=1&ipaddress='+PHP.urlencode(this.ip));}
this.onreadystatechange=function()
{if(me.xml_sender.handler.readyState==4&&me.xml_sender.handler.status==200)
{if(me.xml_sender.handler.responseXML)
{var obj=fetch_object(me.objid);obj.parentNode.insertBefore(document.createTextNode(me.xml_sender.fetch_data(fetch_tags(me.xml_sender.handler.responseXML,'ipaddress')[0])),obj);obj.parentNode.removeChild(obj);}
if(is_ie)
{me.xml_sender.handler.abort();}}}}
function resolve_ip_click(e)
{var resolver=new vB_AJAX_WolResolve(this.innerHTML,this.id);resolver.resolve();return false;}