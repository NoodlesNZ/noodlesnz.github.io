
function vB_AJAX_ThreadRate_Init(formid)
{var formobj=fetch_object(formid);if(AJAX_Compatible&&(typeof vb_disable_ajax=='undefined'||vb_disable_ajax<2)&&formobj)
{for(var i=0;i<formobj.elements.length;i++)
{if(formobj.elements[i].type=='submit')
{var sbutton=formobj.elements[i];var button=document.createElement('input');button.type='button';button.className=sbutton.className;button.value=sbutton.value;button.onclick=vB_AJAX_ThreadRate.prototype.form_click;sbutton.parentNode.insertBefore(button,sbutton);sbutton.parentNode.removeChild(sbutton);}}}};function vB_AJAX_ThreadRate(formobj)
{this.xml_sender=null;this.pseudoform=new vB_Hidden_Form('threadrate.php');this.pseudoform.add_variable('ajax',1);this.pseudoform.add_variables_from_object(formobj);this.output_element_id='threadrating_current';var me=this;this.handle_ajax_response=function()
{if(me.xml_sender.handler.readyState==4&&me.xml_sender.handler.status==200)
{if(me.xml_sender.handler.responseXML)
{var obj=fetch_object(me.objid);var error=me.xml_sender.fetch_data(fetch_tags(me.xml_sender.handler.responseXML,'error')[0]);if(error)
{if(vBmenu.activemenu=='threadrating')
{vBmenu.hide();}
alert(error);}
else
{var newrating=me.xml_sender.fetch_data(fetch_tags(me.xml_sender.handler.responseXML,'voteavg')[0]);if(newrating!='')
{fetch_object(me.output_element_id).innerHTML=newrating;}
if(vBmenu.activemenu=='threadrating')
{vBmenu.hide();}
var message=me.xml_sender.fetch_data(fetch_tags(me.xml_sender.handler.responseXML,'message')[0]);if(message)
{alert(message);}}}
if(is_ie)
{me.xml_sender.handler.abort();}}}};vB_AJAX_ThreadRate.prototype.rate=function()
{if(this.pseudoform.fetch_variable('vote')!=null)
{this.xml_sender=new vB_AJAX_Handler(true);this.xml_sender.onreadystatechange(this.handle_ajax_response);this.xml_sender.send('threadrate.php?t='+threadid+'&vote='+PHP.urlencode(this.pseudoform.fetch_variable('vote')),this.pseudoform.build_query_string());}};vB_AJAX_ThreadRate.prototype.form_click=function()
{var AJAX_ThreadRate=new vB_AJAX_ThreadRate(this.form);AJAX_ThreadRate.rate();return false;};