
function vB_Attachment(listobjid,editorid)
{this.attachments=new Array();this.menu_contents=new Array();this.windows=new Array();this.listobjid=listobjid;if(editorid=='')
{for(var editorid in vB_Editor)
{if(typeof vB_Editor[editorid]!='function')
{this.editorid=editorid;break;}}}
else
{this.editorid=(editorid?editorid:null);}};vB_Attachment.prototype.popup_exists=function()
{if(this.editorid&&((typeof vB_Editor[this.editorid].popups['attach']!='undefined'&&vB_Editor[this.editorid].popups['attach']!=null)||(!vB_Editor[this.editorid].popupmode&&typeof vB_Editor[this.editorid].buttons['attach']!='undefined'&&vB_Editor[this.editorid].buttons['attach']!=null)))
{return true;}
else
{return false;}};vB_Attachment.prototype.add=function(id,filename,filesize,imgpath)
{this.attachments[id]=new Array();this.attachments[id]={'filename':filename,'filesize':filesize,'imgpath':imgpath};this.update_list();};vB_Attachment.prototype.remove=function(id)
{if(typeof this.attachments[id]!='undefined')
{this.attachments[id]=null;this.update_list();}};vB_Attachment.prototype.has_attachments=function()
{for(var id in this.attachments)
{if(this.attachments[id]!=null)
{return true;}}
return false;};vB_Attachment.prototype.reset=function()
{this.attachments=new Array();this.update_list();};vB_Attachment.prototype.build_list=function(listobjid)
{var listobj=fetch_object(listobjid);if(listobjid!=null)
{while(listobj.hasChildNodes())
{listobj.removeChild(listobj.firstChild);}
for(var id in this.attachments)
{var div=document.createElement('div');if(typeof newpost_attachmentbit!='undefined')
{div.innerHTML=construct_phrase(newpost_attachmentbit,this.attachments[id]['imgpath'],SESSIONURL,id,Math.ceil((new Date().getTime())/1000),this.attachments[id]['filename'],this.attachments[id]['filesize']);}
else
{div.innerHTML='<div style="margin:2px"><img src="'+this.attachments[id]['imgpath']+'" alt="" class="inlineimg" /> '+'<a href="attachment.php?'+SESSIONURL+'attachmentid='+id+'&stc=1&d='+Math.ceil((new Date().getTime())/1000)+'" target="_blank" />'+this.attachments[id]['filename']+'</a> '+'('+this.attachments[id]['filesize']+')</div>';}
listobj.appendChild(div);}}};vB_Attachment.prototype.update_list=function()
{this.build_list(this.listobjid);if(this.popup_exists())
{vB_Editor[this.editorid].build_attachments_popup(vB_Editor[this.editorid].popupmode?vB_Editor[this.editorid].popups['attach']:vB_Editor[this.editorid].buttons['attach'],vB_Editor[this.editorid].buttons['attach']);}};vB_Attachment.prototype.open_window=function(url,width,height,hash)
{if(typeof(this.windows[hash])!='undefined'&&this.windows[hash].closed==false)
{this.windows[hash].focus();}
else
{this.windows[hash]=openWindow(url,width,height,'Attach'+hash);}
return this.windows[hash];};