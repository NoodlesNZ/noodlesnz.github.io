
function vB_Inline_Mod(varname,type,formobjid,go_phrase,cookieprefix)
{this.varname=varname;this.type=type.toLowerCase();this.formobj=fetch_object(formobjid);this.go_phrase=go_phrase;if(typeof cookieprefix!='undefined')
{this.cookieprefix=cookieprefix;}
else
{this.cookieprefix='vbulletin_inline';}
if(this.type=='thread')
{this.list='tlist_';}
else if(this.type=='post')
{this.list='plist_';}
else
{this.list=this.type+'list_';}
this.cookie_ids=null;this.cookie_array=new Array();this.init=function(elements)
{for(i=0;i<elements.length;i++)
{if(this.is_in_list(elements[i]))
{elements[i].inlineModID=this.varname;elements[i].onclick=inlinemod_checkbox_onclick;}}
this.cookie_array=new Array();if(this.fetch_ids())
{for(i in this.cookie_ids)
{if(this.cookie_ids[i]!='')
{if(checkbox=fetch_object(this.list+this.cookie_ids[i]))
{checkbox.checked=true;eval('this.highlight_'+this.type+'(checkbox)');}
this.cookie_array[this.cookie_array.length]=this.cookie_ids[i];}}}
this.set_output_counters();}
this.fetch_ids=function()
{this.cookie_ids=fetch_cookie(this.cookieprefix+this.type);if(this.cookie_ids!=null&&this.cookie_ids!='')
{this.cookie_ids=this.cookie_ids.split('-');if(this.cookie_ids.length>0)
{return true;}}
return false;}
this.toggle=function(checkbox)
{eval('this.highlight_'+this.type+'(checkbox)');this.save(checkbox.id.substring(this.list.length),checkbox.checked);}
this.save=function(checkboxid,checked)
{this.cookie_array=new Array();if(this.fetch_ids())
{for(i in this.cookie_ids)
{if(this.cookie_ids[i]!=checkboxid&&this.cookie_ids[i]!='')
{this.cookie_array[this.cookie_array.length]=this.cookie_ids[i];}}}
if(checked)
{this.cookie_array[this.cookie_array.length]=checkboxid;}
this.set_output_counters();this.set_cookie();return true;}
this.set_cookie=function()
{expires=new Date();expires.setTime(expires.getTime()+3600000);set_cookie(this.cookieprefix+this.type,this.cookie_array.join('-'),expires);}
this.check_all=function(checked,itemtype,caller)
{if(typeof checked=='undefined')
{checked=this.formobj.allbox.checked;}
this.cookie_array=new Array();if(this.fetch_ids())
{for(i in this.cookie_ids)
{if(!fetch_object(this.list+this.cookie_ids[i]))
{this.cookie_array[this.cookie_array.length]=this.cookie_ids[i]}}}
counter=0;for(var i=0;i<this.formobj.elements.length;i++)
{if(this.is_in_list(this.formobj.elements[i]))
{elm=this.formobj.elements[i];if(typeof itemtype!='undefined')
{if(elm.value&itemtype)
{elm.checked=checked;}
else
{elm.checked=!checked;}}
else if(checked=='invert')
{elm.checked=!elm.checked;}
else
{elm.checked=checked;}
eval('this.highlight_'+this.type+'(elm)');if(elm.checked)
{this.cookie_array[this.cookie_array.length]=elm.id.substring(this.list.length)}}}
this.set_output_counters();this.set_cookie();return true;}
this.is_in_list=function(obj)
{return(obj.type=='checkbox'&&obj.id.indexOf(this.list)==0&&(obj.disabled==false||obj.disabled=='undefined'));}
this.set_output_counters=function()
{if(this.type=='thread'||this.type=='post')
{var gobutton='inlinego';}
else
{var gobutton=this.type+'_inlinego';}
if(obj=fetch_object(gobutton))
{obj.value=construct_phrase(this.go_phrase,this.cookie_array.length);}}
this.toggle_highlight=function(cell,checkbox)
{if(typeof YAHOO!="undefined")
{if(YAHOO.util.Dom.hasClass(cell,"alt1")||YAHOO.util.Dom.hasClass(cell,"alt2")||YAHOO.util.Dom.hasClass(cell,"inlinemod"))
{if(checkbox.checked)
{if(!cell.oclassName)
{cell.oclassName=cell.className;}
YAHOO.util.Dom.addClass(cell,"inlinemod");}
else if(cell.oclassName)
{cell.className=cell.oclassName;}}}
else
{if(cell.className=='alt1'||cell.className=='alt2'||cell.className=='inlinemod')
{if(checkbox.checked)
{if(!cell.oclassName)
{cell.oclassName=cell.className;}
cell.className='inlinemod';}
else if(cell.oclassName)
{cell.className=cell.oclassName;}}}}
this.highlight_thread=function(checkbox)
{tobj=checkbox;while(tobj.tagName!='TR')
{if(tobj.parentNode.tagName=='HTML')
{break;}
else
{tobj=tobj.parentNode;}}
if(tobj.tagName=='TR')
{tds=tobj.childNodes;for(var i=0;i<tds.length;i++)
{this.toggle_highlight(tds[i],checkbox);}}}
this.highlight_post=function(checkbox)
{if(table=fetch_object('post'+checkbox.id.substr(6)))
{tds=fetch_tags(table,'td');for(var i=0;i<tds.length;i++)
{this.toggle_highlight(tds[i],checkbox);}}}
this.init(this.formobj.elements);}
function inlinemod_checkbox_onclick(e)
{var inlineModObj=eval(this.inlineModID);inlineModObj.toggle(this);};function im_init(obj,inlineobj)
{var inputs=fetch_tags(obj,'input');if(typeof inlineobj=='object'&&typeof inlineobj.init=='function')
{inlineobj.init(inputs);}
else
{inlineMod.init(inputs);}}