
function display_post(postid)
{if(AJAX_Compatible)
{vB_PostLoader[postid]=new vB_AJAX_PostLoader(postid);vB_PostLoader[postid].init();}
else
{pc_obj=fetch_object('postcount'+this.postid);openWindow('showpost.php?'+(SESSIONURL?'s='+SESSIONURL:'')+(pc_obj!=null?'&postcount='+PHP.urlencode(pc_obj.name):'')+'&p='+postid);}
return false;};var vB_PostLoader=new Array();function vB_AJAX_PostLoader(postid)
{this.postid=postid;this.container=fetch_object('edit'+this.postid);};vB_AJAX_PostLoader.prototype.init=function()
{if(this.container)
{postid=this.postid;pc_obj=fetch_object('postcount'+this.postid);this.ajax=new vB_AJAX_Handler(true);this.ajax.onreadystatechange(vB_PostLoader[postid].ajax_check);this.ajax.send('showpost.php?p='+this.postid,'ajax=1&postid='+this.postid+
(pc_obj!=null?'&postcount='+PHP.urlencode(pc_obj.name):''));}};vB_AJAX_PostLoader.prototype.ajax_check=function()
{var AJAX=vB_PostLoader[postid].ajax.handler;if(AJAX.readyState==4&&AJAX.status==200)
{vB_PostLoader[postid].display(AJAX.responseXML);if(is_ie)
{AJAX.abort();}}
return false;};vB_AJAX_PostLoader.prototype.display=function(postbit_xml)
{if(fetch_tag_count(postbit_xml,'postbit'))
{this.container.innerHTML=this.ajax.fetch_data(fetch_tags(postbit_xml,'postbit')[0]);PostBit_Init(fetch_object('post'+this.postid),this.postid);}
else
{openWindow('showpost.php?'+(SESSIONURL?'s='+SESSIONURL:'')+(pc_obj!=null?'&postcount='+PHP.urlencode(pc_obj.name):'')+'&p='+this.postid);}};