
function vB_AJAX_QuickEdit_Init(postobj)
{if(AJAX_Compatible)
{if(typeof postobj=='string')
{postobj=fetch_object(postobj);}
var anchors=fetch_tags(postobj,'a');var postid=0;for(var i=0;i<anchors.length;i++)
{if(anchors[i].name&&anchors[i].name.indexOf('vB::QuickEdit::')!=-1)
{anchors[i].onclick=vB_AJAX_QuickEditor_Events.prototype.editbutton_click;}}}}
function vB_AJAX_QuickEditor()
{this.postid=null;this.messageobj=null;this.container=null;this.originalhtml=null;this.ajax=null;this.editstate=false;this.editorcounter=0;this.pending=false;}
vB_AJAX_QuickEditor.prototype.ready=function()
{if(this.editstate||this.pending)
{return false;}
else
{return true;}};vB_AJAX_QuickEditor.prototype.edit=function(anchor_name)
{var test_ajax=new vB_AJAX_Handler(true);if(!test_ajax.init()||(typeof vb_disable_ajax!='undefined'&&vb_disable_ajax>0))
{return true;}
var tmppostid=anchor_name.substr(anchor_name.lastIndexOf('::')+2);if(this.pending)
{return false;}
else if(!this.ready())
{if(this.postid==tmppostid)
{this.full_edit();return false;}
this.abort();}
this.editorcounter++;this.editorid='vB_Editor_QE_'+this.editorcounter;this.postid=tmppostid;this.messageobj=fetch_object('post_message_'+this.postid);this.originalhtml=this.messageobj.innerHTML;this.unchanged=null;this.unchanged_reason=null;this.fetch_editor();this.editstate=true;return false;};vB_AJAX_QuickEditor.prototype.fetch_editor=function()
{if(fetch_object('progress_'+this.postid))
{fetch_object('progress_'+this.postid).style.display='';}
document.body.style.cursor='wait';this.ajax=new vB_AJAX_Handler(true);this.ajax.onreadystatechange(this.display_editor);this.ajax.send('ajax.php?do=quickedit&p='+this.postid,'do=quickedit&p='+this.postid+'&editorid='+PHP.urlencode(this.editorid));this.pending=true;};vB_AJAX_QuickEditor.prototype.display_editor=function()
{var AJAX=vB_QuickEditor.ajax.handler;if(AJAX.readyState==4&&AJAX.status==200)
{if(fetch_object('progress_'+vB_QuickEditor.postid))
{fetch_object('progress_'+vB_QuickEditor.postid).style.display='none';}
document.body.style.cursor='auto';vB_QuickEditor.pending=false;if(fetch_tag_count(AJAX.responseXML,'disabled'))
{window.location='editpost.php?'+SESSIONURL+'do=editpost&postid='+vB_QuickEditor.postid;}
else if(fetch_tag_count(AJAX.responseXML,'error'))
{}
else
{var editor=fetch_tags(AJAX.responseXML,'editor')[0];var reason=editor.getAttribute('reason');vB_QuickEditor.messageobj.innerHTML=vB_QuickEditor.ajax.fetch_data(editor);if(fetch_object(vB_QuickEditor.editorid+'_edit_reason'))
{vB_QuickEditor.unchanged_reason=PHP.unhtmlspecialchars(reason);fetch_object(vB_QuickEditor.editorid+'_edit_reason').value=vB_QuickEditor.unchanged_reason;fetch_object(vB_QuickEditor.editorid+'_edit_reason').onkeypress=vB_AJAX_QuickEditor_Events.prototype.reason_key_trap;}
vB_Editor[vB_QuickEditor.editorid]=new vB_Text_Editor(vB_QuickEditor.editorid,editor.getAttribute('mode'),editor.getAttribute('parsetype'),editor.getAttribute('parsesmilies'));if(fetch_object(vB_QuickEditor.editorid+'_editor')&&fetch_object(vB_QuickEditor.editorid+'_editor').scrollIntoView)
{fetch_object(vB_QuickEditor.editorid+'_editor').scrollIntoView(true);}
vB_Editor[vB_QuickEditor.editorid].editbox.style.width='100%';vB_Editor[vB_QuickEditor.editorid].check_focus();vB_QuickEditor.unchanged=vB_Editor[vB_QuickEditor.editorid].get_editor_contents();fetch_object(vB_QuickEditor.editorid+'_save').onclick=vB_QuickEditor.save;fetch_object(vB_QuickEditor.editorid+'_abort').onclick=vB_QuickEditor.abort;fetch_object(vB_QuickEditor.editorid+'_adv').onclick=vB_QuickEditor.full_edit;var delbutton=fetch_object(vB_QuickEditor.editorid+'_delete');if(delbutton)
{delbutton.onclick=vB_QuickEditor.show_delete;}}
if(is_ie)
{AJAX.abort();}}};vB_AJAX_QuickEditor.prototype.restore=function(post_html,type)
{this.hide_errors(true);if(this.editorid&&vB_Editor[this.editorid]&&vB_Editor[this.editorid].initialized)
{vB_Editor[this.editorid].destroy();}
if(type=='tableobj')
{fetch_object('edit'+this.postid).innerHTML=post_html;}
else
{this.messageobj.innerHTML=post_html;}
this.editstate=false;};vB_AJAX_QuickEditor.prototype.abort=function(e)
{if(fetch_object('progress_'+vB_QuickEditor.postid))
{fetch_object('progress_'+vB_QuickEditor.postid).style.display='none';}
document.body.style.cursor='auto';vB_QuickEditor.restore(vB_QuickEditor.originalhtml,'messageobj');};vB_AJAX_QuickEditor.prototype.full_edit=function(e)
{var form=new vB_Hidden_Form('editpost.php?do=editpost&postid='+vB_QuickEditor.postid);form.add_variable('do','updatepost');form.add_variable('s',fetch_sessionhash());form.add_variable('advanced',1);form.add_variable('postid',vB_QuickEditor.postid);form.add_variable('wysiwyg',vB_Editor[vB_QuickEditor.editorid].wysiwyg_mode);form.add_variable('message',vB_Editor[vB_QuickEditor.editorid].get_editor_contents());form.add_variable('reason',fetch_object(vB_QuickEditor.editorid+'_edit_reason').value);form.submit_form();}
vB_AJAX_QuickEditor.prototype.save=function(e)
{var newtext=vB_Editor[vB_QuickEditor.editorid].get_editor_contents();var newreason=vB_Editor[vB_QuickEditor.editorid];if(newtext==vB_QuickEditor.unchanged&&newreason==vB_QuickEditor.unchanged_reason)
{vB_QuickEditor.abort(e);}
else
{fetch_object(vB_QuickEditor.editorid+'_posting_msg').style.display='';document.body.style.cursor='wait';pc_obj=fetch_object('postcount'+vB_QuickEditor.postid);vB_QuickEditor.ajax=new vB_AJAX_Handler(true);vB_QuickEditor.ajax.onreadystatechange(vB_QuickEditor.update);vB_QuickEditor.ajax.send('editpost.php?do=updatepost&postid='+vB_QuickEditor.postid,'do=updatepost&ajax=1&postid='
+vB_QuickEditor.postid
+'&wysiwyg='+vB_Editor[vB_QuickEditor.editorid].wysiwyg_mode
+'&message='+PHP.urlencode(newtext)
+'&reason='+PHP.urlencode(fetch_object(vB_QuickEditor.editorid+'_edit_reason').value)
+(pc_obj!=null?'&postcount='+PHP.urlencode(pc_obj.name):''));vB_QuickEditor.pending=true;}};vB_AJAX_QuickEditor.prototype.show_delete=function()
{vB_QuickEditor.deletedialog=fetch_object('quickedit_delete');if(vB_QuickEditor.deletedialog&&vB_QuickEditor.deletedialog.style.display!='')
{vB_QuickEditor.deletedialog.style.display='';vB_QuickEditor.deletebutton=fetch_object('quickedit_dodelete');vB_QuickEditor.deletebutton.onclick=vB_QuickEditor.delete_post;if(!is_opera&&!is_saf)
{vB_QuickEditor.deletebutton.disabled=true;vB_QuickEditor.deleteoptions=new Array();vB_QuickEditor.deleteoptions['leave']=fetch_object('rb_del_leave');vB_QuickEditor.deleteoptions['soft']=fetch_object('rb_del_soft');vB_QuickEditor.deleteoptions['hard']=fetch_object('rb_del_hard');for(var i in vB_QuickEditor.deleteoptions)
{if(vB_QuickEditor.deleteoptions[i])
{vB_QuickEditor.deleteoptions[i].onclick=vB_QuickEditor.deleteoptions[i].onchange=vB_AJAX_QuickEditor_Events.prototype.delete_button_handler;}}}}};vB_AJAX_QuickEditor.prototype.delete_post=function()
{var dontdelete=fetch_object('rb_del_leave');if(dontdelete&&dontdelete.checked)
{vB_QuickEditor.abort();return;}
var form=new vB_Hidden_Form('editpost.php');form.add_variable('do','deletepost');form.add_variable('s',fetch_sessionhash());form.add_variable('postid',vB_QuickEditor.postid);form.add_variables_from_object(vB_QuickEditor.deletedialog);form.submit_form();};vB_AJAX_QuickEditor.prototype.update=function()
{var AJAX=vB_QuickEditor.ajax.handler;if(AJAX.readyState==4&&AJAX.status==200)
{vB_QuickEditor.pending=false;document.body.style.cursor='auto';fetch_object(vB_QuickEditor.editorid+'_posting_msg').style.display='none';if(fetch_tag_count(AJAX.responseXML,'error'))
{var errors=fetch_tags(AJAX.responseXML,'error');var error_html='<ol>';for(var i=0;i<errors.length;i++)
{error_html+='<li>'+vB_QuickEditor.ajax.fetch_data(errors[i])+'</li>';}
error_html+='</ol>';vB_QuickEditor.show_errors('<ol>'+error_html+'</ol>');}
else
{vB_QuickEditor.restore(vB_QuickEditor.ajax.fetch_data(fetch_tags(AJAX.responseXML,'postbit')[0]),'tableobj');PostBit_Init(fetch_object('post'+vB_QuickEditor.postid),vB_QuickEditor.postid);}
if(is_ie)
{AJAX.abort();}}
return false;};vB_AJAX_QuickEditor.prototype.show_errors=function(errortext)
{fetch_object('ajax_post_errors_message').innerHTML=errortext;var errortable=fetch_object('ajax_post_errors');errortable.style.width='400px';errortable.style.zIndex=500;var measurer=(is_saf?'body':'documentElement');errortable.style.left=(is_ie?document.documentElement.clientWidth:self.innerWidth)/2-200+document[measurer].scrollLeft+'px';errortable.style.top=(is_ie?document.documentElement.clientHeight:self.innerHeight)/2-150+document[measurer].scrollTop+'px';errortable.style.display='';};vB_AJAX_QuickEditor.prototype.hide_errors=function(skip_focus_check)
{this.errors=false;fetch_object('ajax_post_errors').style.display='none';if(skip_focus_check!=true)
{vB_Editor[this.editorid].check_focus();}};function vB_AJAX_QuickEditor_Events()
{}
vB_AJAX_QuickEditor_Events.prototype.editbutton_click=function(e)
{return vB_QuickEditor.edit(this.name);};vB_AJAX_QuickEditor_Events.prototype.delete_button_handler=function(e)
{if(this.id=='rb_del_leave'&&this.checked)
{vB_QuickEditor.deletebutton.disabled=true;}
else
{vB_QuickEditor.deletebutton.disabled=false;}}
vB_AJAX_QuickEditor_Events.prototype.reason_key_trap=function(e)
{e=e?e:window.event;switch(e.keyCode)
{case 9:{fetch_object(vB_QuickEditor.editorid+'_save').focus();return false;}
break;case 13:{vB_QuickEditor.save();return false;}
break;default:{return true;}}}
var vB_QuickEditor=new vB_AJAX_QuickEditor();