
function vB_AJAX_ImageReg_Init()
{if(AJAX_Compatible&&(typeof vb_disable_ajax=='undefined'||vb_disable_ajax<2)&&fetch_object('refresh_imagereg'))
{fetch_object('refresh_imagereg').onclick=vB_AJAX_ImageReg.prototype.image_click;fetch_object('refresh_imagereg').style.cursor=pointer_cursor;fetch_object('refresh_imagereg').style.display='';if(fetch_object('imagereg'))
{fetch_object('imagereg').style.cursor=pointer_cursor;fetch_object('imagereg').onclick=vB_AJAX_ImageReg.prototype.image_click;}}};function vB_AJAX_ImageReg()
{this.xml_sender=null;this.imagehash='';var me=this;this.handle_ajax_response=function()
{if(me.xml_sender.handler.readyState==4&&me.xml_sender.handler.status==200)
{fetch_object('progress_imagereg').style.display='none';if(me.xml_sender.handler.responseXML)
{var error=me.xml_sender.fetch_data(fetch_tags(me.xml_sender.handler.responseXML,'error')[0]);if(error)
{alert(error);}
else
{var imagehash=me.xml_sender.fetch_data(fetch_tags(me.xml_sender.handler.responseXML,'imagehash')[0]);if(imagehash)
{fetch_object('imagehash').value=imagehash;fetch_object('imagereg').src='image.php?'+SESSIONURL+'type=regcheck&imagehash='+imagehash;}}}
if(is_ie)
{me.xml_sender.handler.abort();}}}};vB_AJAX_ImageReg.prototype.fetch_image=function()
{fetch_object('progress_imagereg').style.display='';this.xml_sender=new vB_AJAX_Handler(true);this.xml_sender.onreadystatechange(this.handle_ajax_response);this.xml_sender.send('ajax.php?do=imagereg&imagehash='+this.imagehash,'do=imagereg&imagehash='+this.imagehash);};vB_AJAX_ImageReg.prototype.image_click=function()
{var AJAX_ImageReg=new vB_AJAX_ImageReg();AJAX_ImageReg.imagehash=fetch_object('imagehash').value;AJAX_ImageReg.fetch_image();return false;};